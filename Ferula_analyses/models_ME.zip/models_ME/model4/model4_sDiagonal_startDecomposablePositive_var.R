library(PCMBaseCpp)
library(mvSLOUCH)
library(ape)

### function for rescaling tree to relative lenght 1 ###

edge_cutoff<-0.02

fprep_edges<-function(phyltree,edge_cutoff,new_height=1){
    phyltree$edge.length<-new_height*(phyltree$edge.length/max(ape::node.depth.edgelength(phyltree)))
    phyltree$edge.length[which(phyltree$edge.length<edge_cutoff)]<-edge_cutoff
    if (!ape::is.ultrametric(phyltree)){
        vnode_heights_all<-node.depth.edgelength(phyltree)
        curr_height<-max(vnode_heights_all)    

	### code from phyltree_paths.R ###

	vnodes_edgecol1<-sort(unique(phyltree$edge[,1]))
	vnodes_edgecol2<-sort(unique(phyltree$edge[,2]))
	tip_species_index<-sort(setdiff(vnodes_edgecol2,vnodes_edgecol1)) ### only those nodes that are an ending
    
	
	edge_lengthen_all<-rep(0,length(phyltree$edge.length))
	vedge_id<-which(is.element(phyltree$edge[,2],tip_species_index))
	vedge_id<-vedge_id[order(phyltree$edge[vedge_id,2])]
	edge_lengthen_all[vedge_id]<-curr_height-vnode_heights_all[tip_species_index]
	
	phyltree$edge.length<-phyltree$edge.length+edge_lengthen_all
	phyltree$edge.length<-new_height*(phyltree$edge.length/max(ape::node.depth.edgelength(phyltree)))
    }    
    phyltree
}

### Read files ###

ferulatreeape<-read.tree("Ferula_fruits_tree.txt")
ferulatreeape<-fprep_edges(ferulatreeape,edge_cutoff,new_height=1)

feruladata_all <-read.csv("Data_ME.csv",header=TRUE,row.names=1)
feruladata_all <-feruladata_all[ferulatreeape$tip.label,]

### set directiory for output and set output files ###

v_means<-colnames(feruladata_all)[1:5]
v_vars<-colnames(feruladata_all)[6:10]

feruladata <- data.matrix(feruladata_all[,v_means, drop=FALSE])
M.error<-sapply(1:nrow(feruladata_all),function(i,feruladata_all,v_vars){x<-feruladata_all[i,v_vars];diag(c(x,0), nrow=5, ncol=5)},feruladata_all=feruladata_all,v_vars=v_vars,simplify=FALSE)

OUOUmodeldiagonal_table <- data.frame(matrix(ncol=9, nrow=1000))
columns <- c("i", "seed_start_point", "seed", "aic", "aic.c", "sic", "bic", "R2", "logLik")
colnames(OUOUmodeldiagonal_table) <- columns

dir.create("model4_sDiagonal_startDecomposablePositive")
setwd("model4_sDiagonal_startDecomposablePositive")

### Repeat model estimation 1000 times starting from various starting points ###

for(i in 1:1000) {

seed1 <- 10+i 
set.seed(seed1)

OUOUmodel_start <- ouchModel(ferulatreeape, feruladata, regimes=NULL, Atype="DecomposablePositive", Syytype="Diagonal", diagA=NULL, maxiter=c(25,50))

seed2 <- 1991+i
set.seed(seed2)

myfile <- paste(i, "_", "model4_sDiagonal_startDecomposablePositive", "_", seed2, ".txt", sep="")

### model4_sDiagonal_startDecomposablePositive ###

OUOUmodel <- ouchModel(ferulatreeape, feruladata, regimes=NULL, Atype="Any", Syytype="Diagonal", diagA=NULL, maxiter=c(100,1000), M.error=M.error, start_point_for_optim=list(A=OUOUmodel_start$FinalFound$ParamsInModel$A, Syy=OUOUmodel_start$FinalFound$ParamsInModel$Syy), parameter_signs=list(signsA=rbind(c("+",NA,"0","0","0"),c(NA,"+","0","0","0"),c("0","0","+",NA,"0"),c("0","0",NA,"+","0"),c("0","0","0","0","+"))))

OUOUmodeldiagonal_table[i,1] <- i
OUOUmodeldiagonal_table[i,2] <- seed1
OUOUmodeldiagonal_table[i,3] <- seed2
OUOUmodeldiagonal_table[i,4] <- OUOUmodel$FinalFound$ParamSummary$aic
OUOUmodeldiagonal_table[i,5] <- OUOUmodel$FinalFound$ParamSummary$aic.c
OUOUmodeldiagonal_table[i,6] <- OUOUmodel$FinalFound$ParamSummary$sic
OUOUmodeldiagonal_table[i,7] <- OUOUmodel$FinalFound$ParamSummary$bic
OUOUmodeldiagonal_table[i,8] <- OUOUmodel$FinalFound$ParamSummary$RSS$R2
OUOUmodeldiagonal_table[i,9] <- OUOUmodel$FinalFound$ParamSummary$LogLik

capture.output(OUOUmodel,file=myfile)

}

setwd("..") 
write.csv(OUOUmodeldiagonal_table, file="model4_sDiagonal_startDecomposablePositive_var.csv", row.names = F) ### output
