

## README

# 1. After extraction of the zip folder (Fast_mvSLOUCH_example.zip), place the folder where you seek to perform analyses.

# 2. Set the working directory to this folder - setwd()

# 3. Use this R script Fast_mvSLOUCH_example.R script

# 4. If you want to run everything again (it will take at least 2 weeks using 6 cores on a laptop), set 
#    runtype <- "novel.run" 
#    at the top of the code. This will overwrite any outputs already in the folder, only drawing data from
#    the INPUTS folder. You may find it easier therefore, to delete or move all files and folders except for 
#    the INPUTS FOLDER and this script.

# 5. If you wish to run the code without fitting the models, but by loading our model outputs as presented in the paper, set:
#    runtype <- "load.previous.outputs" 
#    This will enable you to examine our outputs within R.



# Set runtype
runtype <- "load.previous.outputs"  # "load.previous.outputs" or "novel.run" 



#~~~~~~~~~~  
# Contents  - these are the main sections in the script



## Analysis set up ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Regime specification ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Run main mvSLOUCH models without additional customisations ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## If you want to load models you have run  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## If you want to load models you have run  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Harvest key information from all runs of every model ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Harvest key information from all runs of every model 2nd look ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## Parametric bootstrap the best model ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Derive key metrics from bootstraps ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~










## Analysis set up ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# For the vignette of the package, find details with browseVignettes("mvSLOUCH")

# R version 4.1.0 (2021-05-18) -- "Camp Pontanezen"
# Copyright (C) 2021 The R Foundation for Statistical Computing
# Platform: x86_64-w64-mingw32/x64 (64-bit)

# install.packages("foreach")
# install.packages("doParallel")
# install.packages("PCMBaseCpp")
# install.packages("ape")
library("foreach")
library("doParallel")
library("mvSLOUCH")
library("PCMBaseCpp")
library("ape")
library("rlist")
library("phytools")

## -----------------------------------------------------------------------------
# RNGversion can be used to set the random generators as they were in an earlier R version (for reproducibility).

RNGversion("3.6.1") # - Sets RNG to a specific version (e.g. pick one at random, such as an older version).

# The function set.seed() allows specifying a starting point in a sequence of randomly generated numbers 
# so that a user can obtain the same outputs under a given process. For the purposes of the current example,
# if you want to replicate the outputs below (for mvSLOUCH 2.7.2), set up the following seed:

# Set a specific seed, so all analyses below can be replicated        
# set.seed is the recommended way to specify seeds.
set.seed(seed=5, # seed, a single value, interpreted as an integer, or NULL 
         kind = "Mersenne-Twister", # to set the kind (i.e. type) of random number generator. 
         normal.kind = "Inversion")

# Now this is set, every item that is run from this point onwards should match our values.
# We will also set values for each individual analysis, so that any specific part can be easily replicated.


## Supertree
phyltree_plants <- ape::read.tree(".//INPUTS//plant tree for mvSLOUCH.tre")


## Trait data + Ellen values                                  
dat <- readRDS(".//INPUTS//4plant.traits.w.Ellenberg.values.rds")

# > head(dat)
#            SpeciesName leaf.area plant.height  seed.mass leaf.mass     Nutrients
# 1       Acer_campestre 2935.1503   13.5435824 53.1641086  90.24579         6
# 2  Acer_monspessulanum  865.4725    8.9738384 40.4075000  69.93007         4
# 3     Acer_platanoides 6215.1196   22.8641277 94.1405946 417.85583         6
# 4  Acer_pseudoplatanus 7193.1459   24.7125730 59.4645004 666.03177         7
# 5     Achillea_collina 1112.9500    0.5733333  0.1466667  61.94400         4
# 6 Achillea_millefolium  678.4196    0.3625520  0.1880422  52.53474         5

# Units:
# leaf area (mm2)
# plant height (m)
# seed mass (mg)
# leaf mass (mg)

# Object looks like this:
# > str(dat)
# 'data.frame':	1252 obs. of  6 variables:
# $ SpeciesName : chr  "Acer_campestre" "Acer_monspessulanum" "Acer_platanoides" "Acer_pseudoplatanus" ...
# $ leaf.area   : num  2935 865 6215 7193 1113 ...
# $ plant.height: num  13.544 8.974 22.864 24.713 0.573 ...
# $ seed.mass   : num  53.164 40.407 94.141 59.465 0.147 ...
# $ leaf.mass   : num  90.2 69.9 417.9 666 61.9 ...
# $ Nutrients   : int  6 4 6 7 4 5 4 6 7 7 ...


## Carnivore package vignette example had species as rownames (below), so we match this:
# ----------
#head(dat)
##                        Ecology    HuL HuPCL    RaL
## Ailurus_fulgens       arboreal 112.82 50.35  87.84
## Vulpes_lagopus      generalist 106.47 44.08 101.89
## Atelocynus_microtis generalist 116.01 52.55 107.78
## Canis_adustus        cursorial 127.84 45.03 135.86
## Canis_latrans        cursorial 160.06 67.03 168.32
## Canis_lupus          cursorial 212.12 92.11 210.94

# > str(head(dat))
# 'data.frame':	6 obs. of  4 variables:
# $ Ecology: chr  "semiaquatic" "semiaquatic" "semiaquatic" "semiaquatic" ...
# $ HuL    : num  65.8 72 78.2 108.2 65.1 ...
# $ HuPCL  : num  34.2 35.5 48.4 66.7 37.9 ...
# $ RaL    : num  53.8 51 55.9 81 47.5 ...
# ----------

rownames(dat) <- dat$SpeciesName
dat$SpeciesName <- NULL
dat <- dat[, c(5, 1:4)]
# > head(dat)
#                      Nutrients leaf.area plant.height  seed.mass leaf.mass
# Acer_campestre               6 2935.1503   13.5435824 53.1641086  90.24579
# Acer_monspessulanum          4  865.4725    8.9738384 40.4075000  69.93007
# Acer_platanoides             6 6215.1196   22.8641277 94.1405946 417.85583
# Acer_pseudoplatanus          7 7193.1459   24.7125730 59.4645004 666.03177
# Achillea_collina             4 1112.9500    0.5733333  0.1466667  61.94400
# Achillea_millefolium         5  678.4196    0.3625520  0.1880422  52.53474

dat$Nutrients <- as.character(dat$Nutrients) # Convert Nutrients to a character   
# Now matches Vignette
# > str(dat)
# 'data.frame':	1252 obs. of  5 variables:
# $ Nutrients   : chr  "6" "4" "6" "7" ...
# $ leaf.area   : num  2935 865 6215 7193 1113 ...
# $ plant.height: num  13.544 8.974 22.864 24.713 0.573 ...
# $ seed.mass   : num  53.164 40.407 94.141 59.465 0.147 ...
# $ leaf.mass   : num  90.2 69.9 417.9 666 61.9 ...

geiger::name.check(phyltree_plants, dat)
# [1] "OK"


# Make data same order as phyogeny tips. Not needed for the functions to work, but
# just to keep it tidy. Order of taxa is used if rownames are not provided (alongside a warning message)
dat <- dat[phyltree_plants$tip.label,] 
Tree <- phyltree_plants

# A practice that can lead to more stable estimations is using trees scaled to maximum tree height, 
# as the smaller numerical branch length values allow the estimator to find the maximum likelihood 
# peak more easily. As currently loaded, this tree is not scaled:
mvSLOUCH::phyltree_paths(Tree)$tree_height
# [1] 138.965

# This is the total tree height, i.e. the amount of time (in millions of years) from the root to the tips 
# (the function mvSLOUCH::phyltree_paths() will be addressed in more detail in Models section). 
# We can scale branch lengths by total tree height to make them a proportion of one:
tree_height <- mvSLOUCH::phyltree_paths(Tree)$tree_height
ScaledTree <- Tree
ScaledTree$edge.length <- ScaledTree$edge.length/tree_height
mvSLOUCH::phyltree_paths(ScaledTree)$tree_height
#[1] 1

# Now the branches are proportionately scaled to the tree height (rather than absolute time), 
# easing the estimation procedure. It is important to ensure that the taxa names in the data and 
# in the tree match, and that the order of names correspond to each other:
geiger::name.check(ScaledTree, dat)
#[1] "OK"

# When this is not the case (i.e. when there is a list of mismatches instead of the OK sign), 
# the data and/or the tree have to be pruned (see the ape package ape::drop.tip(), ape::keep.tip(), 
# for example) or renamed accordingly.





## Regime specification ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# We will use the Nutrient habitat preferences as hypothesized selective regime for the plant traits. 
# mvSLOUCH implements an unordered parsimony algorithm for this purpose of reconstructing the regime 
# states on the phylogeny. First, we need to ensure that the Nutrient habitat categories match the correct 
# species names in the tree. This is typically not the case as the data frame and the phylogenetic tree 
# are usually from independent sources and have species names listed in different orders:
row.names(dat)==ScaledTree$tip.label

# So, we will store the Nutrient habitat categories in a new object where the order is specified 
# according to tree tip names:
regimes <- dat$Nutrients[order(match(row.names(dat), ScaledTree$tip.label))]

# With this new object we can run the parsimony reconstruction:
regimesFitch <- mvSLOUCH::fitch.mvsl(ScaledTree, regimes)
# sink("regimesFitch.txt"); print("table()"); print( table(regimesFitch$branch_regimes) ); print(regimesFitch); sink()
# saveRDS(object, file = "", ascii = FALSE, version = NULL, compress = TRUE, refhook = NULL)

# Try deltran OR acctran = TRUE in the function call in order to implement a delayed or 
# accelerated character transformation

# Manually check regimesFitch, there may be many nodes labelled "ambiguous"

# When the reconstruction involves ambiguous nodes (as in this case), mvSLOUCH offers two options for 
# resolving the character optimization: ACCTRAN (accelerated transformations) and DELTRAN (delayed transformations). 
# The former assigns changes as close to the root of the phylogenetic tree as possible (thus favoring reversals), 
# and the latter as close to the tips as possible (thus favoring convergences). 
# E.g. a DELTRAN illustration would be implemented as below:
regimesFitch <- mvSLOUCH::fitch.mvsl(ScaledTree, regimes, deltran=TRUE)

# mvSLOUCH also offers the possibility of fixing the root to a given character state, 
# which is particularly useful if the root node is ambiguous. We can visualize the reconstruction 
# by painting the branches of the phylogenetic tree with different colors:


# according to the reconstruction:
reg.col <- regimesFitch$branch_regimes
reg.col[reg.col=="1"] <- "#2166ac"
reg.col[reg.col=="2"] <- "#4393c3"
reg.col[reg.col=="3"] <- "#92c5de"
reg.col[reg.col=="4"] <- "#d1e5f0"
reg.col[reg.col=="5"] <- "#f7f7f7"
reg.col[reg.col=="6"] <- "#fddbc7"
reg.col[reg.col=="7"] <- "#f4a582"
reg.col[reg.col=="8"] <- "#d6604d"
reg.col[reg.col=="9"] <- "#b2182b"
reg.col[reg.col=="ambiguous"] <- "black"



pdf(file="Regimes.on.tree_6.pdf", width=7.5, height=10, useDingbats=FALSE) # width=7.5, height=10

plot(ScaledTree, cex=1,  edge.color=reg.col, edge.width=1.2, type="fan", show.tip.label=FALSE)

legend("bottomr", 
       legend=c("1", "2", "3", "4", "5", "6", "7", "8", "9", "ambiguous"),
       col=c( "#2166ac", "#4393c3", "#92c5de", "#d1e5f0", "#f7f7f7", "#fddbc7", "#f4a582", "#d6604d", "#b2182b", "black"), 
       bty = "n", # Removes the legend box
       lty=1, lwd=5,
       x.intersp=0.05,
       cex=1,
       ncol=5) # , 
#horiz = TRUE) # Horizontal legend. You can also set the number of columns with the argument ncol if horiz = FALSE
dev.off()








# > head(dat)
#                       Nutrients  leaf.area plant.height   seed.mass leaf.mass 
# Rudbeckia_hirta               6   594.6938    0.3016000   0.8736072  46.49891  
# Eupatorium_cannabinum         7  3235.6178    1.3241071   0.3334128 246.25354   
# Arnica_montana                3  1848.3800    0.2285000   1.6700000 114.61800  
# Galinsoga_parviflora          8   441.7105    0.4319048   0.2166667  13.68000  
# Helianthus_tuberosus          8 19532.5000    2.0467600   4.4084987 620.08400  
# Xanthium_orientale            7  6825.5000    0.5570000 310.2500000 870.85000  


# Before running analyses, we will log transform the morphological variables so that they are less 
# susceptible to scaling effects:
mvData <- data.matrix(dat[ ,c("leaf.area", "plant.height", "seed.mass", "leaf.mass")])
mvData <- log(mvData)


# mvSLOUCH works faster when the phylogeny object includes information on the paths and distances 
# for each node. This information can be obtained with the function mvSLOUCH::phyltree_paths():
mvStree <- mvSLOUCH::phyltree_paths(ScaledTree) 


colnames(mvData) # [1] "leaf.area"  "plant.height" "seed.mass" "leaf.mass"   

# Order of these names can matter. For various functions you want to use mvData object, 
# where your predictor is the LAST column, and responses are the columns BEFORE that. 
# So, if I want plant height as a predictor in the default model set ups of 
# mvSLOUCH, better to put that in the last column
mvData <- mvData[ , c("seed.mass", "leaf.area", "leaf.mass", "plant.height")]
head(mvData, 2)
#                       seed.mass leaf.area leaf.mass plant.height
#Rudbeckia_hirta       -0.1351244  6.388047  3.839429   -1.1986536
#Eupatorium_cannabinum -1.0983739  8.081975  5.506362    0.2807384


# But when we define our own models later, we specified the A matrix manually. 
# When we designed the matrices, we actually placed plant height in the first column 
# - so will use this reordered data (i.e. mvData2) when running those customised analyses.
mvData2 <- mvData[ , c("plant.height", "seed.mass", "leaf.area", "leaf.mass")]
head(mvData2, 2)
#                       plant.height  seed.mass leaf.area leaf.mass
# Rudbeckia_hirta         -1.1986536 -0.1351244  6.388047  3.839429
# Eupatorium_cannabinum    0.2807384 -1.0983739  8.081975  5.506362










if(runtype = "novel.run") {  # "load.previous.outputs" or "novel.run" 
  
  
  
  
  ## Run main mvSLOUCH models without additional customisation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  
  # If you are mainly using the the typical options available in the main functions of mvMORPH
  # you want to use an mvData object where your predictor is the LAST column, and responses are the columns BEFORE that.
  
  # mvData <- mvData[ , c("seed.mass", "leaf.area", "leaf.mass", "plant.height")]
  # head(mvData, 2)
  #                        seed.mass leaf.area leaf.mass plant.height
  # Rudbeckia_hirta       -0.1351244  6.388047  3.839429   -1.1986536
  # Eupatorium_cannabinum -1.0983739  8.081975  5.506362    0.2807384
  
  
  # Lets start with the models more familiar to users of trait evolution models, in addition
  # to some models unique to mvSLOUCH, just as a demonstration of the different types of models 
  # that can be fit in mvSLOUCH. 
  
  
  # We will then move onto more highly customized models to examine the specific questions
  # that is the focus of the manuscript.
  
  
  # The 7 types of model that can be fit to multivariate data include:
  
  # A. mvBM
  # B. mvOU
  # Then include multiple regimes
  # -. mvBM with regimes (not currently possible in mvSLOUCH)
  # C. mvOU with regimes
  # Then mvOUBM and mvOUOU models of these 2 varieties
  # D. OUBM 
  # E. OUBM with regimes
  # F. OUOU 
  # G. OUOU with regimes
  
  
  # We are only running 1 version of each of these models, just to demonstrate their usage.
  # The papers analyses really focus upon the customised analyses, further down in the code.
  
  # A. mvBM (multivariate Brownian motion)
  start_time <- Sys.time()
  #BM1.seed <- as.numeric(Sys.time()); saveRDS(BM1.seed, "BM1.seed.rds") - when I saved the seed
  BM1.seed <- readRDS("BM1.seed.rds"); set.seed(BM1.seed)
  
  BM1 <- mvSLOUCH::BrownianMotionModel(mvStree, mvData)
  end_time <- Sys.time(); print(end_time - start_time )  
  saveRDS(BM1, "BM1.rds")
  
  sink("BM1.output.txt"); print(BM1); sink()
  
  ## Information for supplement table:
  
  # BM1.output.txt
  # BM1$ParamsInModel$vX0
  # ##                  [,1]
  # seed.mass     0.9286791
  # leaf.area     7.3947083
  # leaf.mass     4.3012785
  # plant.height -0.6625542
  
  # BM1$ParamsInModel$Sxx
  # ##            seed.mass leaf.area leaf.mass plant.height
  # seed.mass     9.7341412  0.000000  0.000000     0.000000
  # leaf.area    -0.3803377  9.796922  0.000000     0.000000
  # leaf.mass     0.4931029  7.863007  5.057536     0.000000
  # plant.height -0.5029735  3.819926  1.920010     4.861071
  
  
  
  # B. mvOU (multivariate  OU)
  start_time <- Sys.time()
  #OU1.seed <- as.numeric(Sys.time()); saveRDS(OU1.seed, "OU1.seed.rds")
  OU1.seed <- readRDS("OU1.seed.rds"); set.seed(OU1.seed)
  
  OU1 <- mvSLOUCH::ouchModel(mvStree, mvData)
  end_time <- Sys.time(); print(end_time - start_time )  
  saveRDS(OU1, "OU1.rds")
  # Time difference of 9.305455 mins
  # Time difference of 50.27727 mins - when comp busy (6 cores used + this in sep window)
  sink("OU1.output.txt"); print(OU1); sink()
  
  ## Information for supplement table:
  
  # OU1.output.txt
  # OU1$FinalFound$ParamsInModel$vY0
  # ##                  [,1]
  # seed.mass     0.8278336
  # leaf.area     7.2749820
  # leaf.mass     4.2183659
  # plant.height -0.6492537
  
  # OU1$FinalFound$ParamsInModel$A
  # ##             seed.mass   leaf.area   leaf.mass plant.height
  # seed.mass     0.37470390  0.03372538 -0.02376106  -0.04559772
  # leaf.area     0.04994001  0.39117487 -0.06204900   0.14893343
  # leaf.mass    -0.05205367  0.03341949  0.32262224  -0.10659924
  # plant.height -0.07770097 -0.03129700  0.04799117   0.37914769
  
  # OU1$FinalFound$ParamsInModel$Syy
  # ##            seed.mass   leaf.area  leaf.mass plant.height
  # seed.mass     1.037792 -0.09224102 0.01095304  -0.08034723
  # leaf.area     0.000000  1.11852671 0.41239536   0.15494376
  # leaf.mass     0.000000  0.00000000 1.07142579   0.39458434
  # plant.height  0.000000  0.00000000 0.00000000   1.06396694
  
  # $FinalFound$ParamsInModel$mPsi
  # ##                reg.1
  # seed.mass     0.8278336
  # leaf.area     7.2749820
  # leaf.mass     4.2183659
  # plant.height -0.6492537
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval
  # ##            Lower.end Estimated.Point  Upper.end
  # seed.mass     0.4404556       0.8278336  1.2152115
  # leaf.area     6.8310459       7.2749820  7.7189180
  # leaf.mass     3.7705583       4.2183659  4.6661735
  # plant.height -1.0354583      -0.6492537 -0.2630492
  
  
  
  
  
  # Then include multiple regimes ____________________
  
  
  
  # - BM + regimes - not currently possible in mvSLOUCH
  
  
  
  # C. mvOU + regimes 
  start_time <- Sys.time()
  #OUestim.seed <- as.numeric(Sys.time()); saveRDS(OUestim.seed, "OUestim.seed.rds") - when I saved the seed
  OUestim.seed <- readRDS("OUestim.seed.rds"); set.seed(OUestim.seed)
  
  OUestim <- mvSLOUCH::ouchModel(mvStree, mvData,
                                 regimes = regimesFitch$branch_regimes)
  end_time <- Sys.time(); print(end_time - start_time ) 
  saveRDS(OUestim, "OUestim.rds")
  # Time difference of 37.83772 mins
  
  sink("OUestim.output.txt"); print(OUestim); sink()
  
  ## Information for supplement table:
  
  # OUestim.output.txt
  # OUestim$FinalFound$ParamsInModel$vY0
  # ##                  [,1]
  # seed.mass     0.4411000
  # leaf.area     7.7927855
  # leaf.mass     4.4983435
  # plant.height -0.3448093
  
  # OUestim$FinalFound$ParamsInModel$A
  # ##              seed.mass   leaf.area    leaf.mass plant.height
  # seed.mass     0.36092037  0.07562425 -0.070000389   -0.2460779
  # leaf.area    -0.05194241  0.41629386 -0.082437699    0.2850946
  # leaf.mass     0.03513679 -0.04623269  0.349262336    0.0720671
  # plant.height -0.09885221 -0.07242682 -0.007481528    0.3485199
  
  # OUestim$FinalFound$ParamsInModel$Syy
  # ##           seed.mass  leaf.area leaf.mass plant.height
  # seed.mass     1.128687 -0.1061225 0.1009144   -0.1560352
  # leaf.area     0.000000  0.9080513 0.3777432    0.2978923
  # leaf.mass     0.000000  0.0000000 0.9120749    0.3202085
  # plant.height  0.000000  0.0000000 0.0000000    1.0793698
  
  # $FinalFound$ParamsInModel$mPsi
  # ##                    1          2          3          4        5          6        7        8        9 ambiguous
  # seed.mass    -24.448818 -19.622934 -15.905917 -2.6350441 8.073529  0.4411000 17.46081 17.72322 11.95778  1.603104
  # leaf.area     -1.315649  -6.889345   1.906071  4.0584075 5.112873  7.7927855 12.78676 17.31161 26.00510 11.192409
  # leaf.mass     -8.606235 -14.748419  -4.923445  0.9225653 4.239723  4.4983435 12.13363 15.73816 27.34076  2.387294
  # plant.height -22.653266 -21.978011 -16.583444 -5.1795781 4.437170 -0.3448093 10.65423 11.74740 12.29237  3.596134
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end
  # ##                   1          2           3          4        5           6         7         8         9  ambiguous
  # seed.mass    -29.145888 -22.239652 -18.5044469 -5.2748563 5.580055 -0.03613929 15.290127 14.161854  1.993082 -11.204090
  # leaf.area     -4.172612  -8.487808   0.3162252  2.4427806 3.586617  7.39332837 11.456948 15.141055 19.956130   3.406758
  # leaf.mass    -11.394533 -16.298904  -6.4691041 -0.6494568 2.758173  4.09758104 10.849701 13.622356 21.423671  -5.254700
  # plant.height -26.446851 -24.082513 -18.6786481 -7.3099840 2.429142 -0.79942168  8.914139  8.872443  4.234210  -6.799225
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point
  # ##                1          2          3          4        5          6        7        8        9 ambiguous
  # seed.mass    -24.448818 -19.622934 -15.905917 -2.6350441 8.073529  0.4411000 17.46081 17.72322 11.95778  1.603104
  # leaf.area     -1.315649  -6.889345   1.906071  4.0584075 5.112873  7.7927855 12.78676 17.31161 26.00510 11.192409
  # leaf.mass     -8.606235 -14.748419  -4.923445  0.9225653 4.239723  4.4983435 12.13363 15.73816 27.34076  2.387294
  # plant.height -22.653266 -21.978011 -16.583444 -5.1795781 4.437170 -0.3448093 10.65423 11.74740 12.29237  3.596134
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end
  # ##                1          2          3            4         5         6        7        8        9 ambiguous
  # seed.mass    -19.751748 -17.006217 -13.307387  0.004768145 10.567004 0.9183392 19.63149 21.28460 21.92248  14.41030
  # leaf.area      1.541315  -5.290883   3.495916  5.674034386  6.639130 8.1922426 14.11657 19.48216 32.05408  18.97806
  # leaf.mass     -5.817937 -13.197933  -3.377786  2.494587474  5.721273 4.8991059 13.41756 17.85397 33.25785  10.02929
  # plant.height -18.859681 -19.873508 -14.488240 -3.049172283  6.445199 0.1098030 12.39432 14.62236 20.35052  13.99149
  
  
  
  # D. OUBM 
  start_time <- Sys.time()
  #OU1BM.seed <- as.numeric(Sys.time()); saveRDS(OU1BM.seed, "OU1BM.seed.rds") - when I saved the seed
  OU1BM.seed <- readRDS("OU1BM.seed.rds"); set.seed(OU1BM.seed)
  
  OU1BM <- mvSLOUCH::mvslouchModel(mvStree, mvData, 
                                   kY = 3, # Number of "Y" (response) variables, for the OUBM models.
                                   predictors = c(4))
  end_time <- Sys.time(); print(end_time - start_time ) 
  saveRDS(OU1BM, "OU1BM.rds")
  # Time difference of 8.771711 mins
  
  sink("OU1BM.output.txt"); print(OU1BM); sink()
  
  ## Information for supplement table:
  
  # OU1BM.output.txt
  # OU1BM$FinalFound$ParamsInModel$vY0
  # ##             [,1]
  # seed.mass 1.072784
  # leaf.area 7.423318
  # leaf.mass 4.458443
  
  # OU1BM$FinalFound$ParamsInModel$A
  # ##            seed.mass  leaf.area  leaf.mass
  # seed.mass  0.4007106225 -0.1660297 0.08070768
  # leaf.area -0.0526211052  0.3255483 0.56102759
  # leaf.mass  0.0007387126 -0.1530621 0.44989998
  
  # OU1BM$FinalFound$ParamsInModel$Syy
  # ##         seed.mass  leaf.area  leaf.mass
  # seed.mass  1.136563 -0.3321989 0.07794339
  # leaf.area  0.000000  1.0056955 0.95572130
  # leaf.mass  0.000000  0.0000000 1.16161090
  
  # $FinalFound$ParamsInModel$mPsi
  # ##           reg.1
  # seed.mass 1.309778
  # leaf.area 7.294368
  # leaf.mass 4.861285
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval
  # ##        Lower.end Estimated.Point Upper.end
  # seed.mass 0.6431436        1.309778  1.976412
  # leaf.area 6.6855512        7.294368  7.903185
  # leaf.mass 4.0365846        4.861285  5.685985
  
  
  
  # E. OUBM + regimes
  start_time <- Sys.time()
  #OUBMestim.seed <- as.numeric(Sys.time()); saveRDS(OUBMestim.seed, "OUBMestim.seed.rds") - when I saved the seed
  OUBMestim.seed <- readRDS("OUBMestim.seed.rds"); set.seed(OUBMestim.seed)
  
  OUBMestim <- mvSLOUCH::mvslouchModel(mvStree, mvData, 
                                       kY = 3, # Number of "Y" (response) variables, for the OUBM models.
                                       predictors = c(4), 
                                       regimes = regimesFitch$branch_regimes)
  end_time <- Sys.time(); print(end_time - start_time ) 
  saveRDS(OUBMestim, "OUBMestim .rds")
  # Time difference of 27.36763 mins
  
  sink("OUBMestim.output.txt"); print(OUBMestim); sink()
  
  ## Information for supplement table:
  
  # OUBMestim.output.txt
  # OUBMestim$FinalFound$ParamsInModel$vY0
  # ##             [,1]
  # seed.mass 0.2897811
  # leaf.area 7.7063038
  # leaf.mass 4.3960861
  
  # OUBMestim$FinalFound$ParamsInModel$A
  # ##         seed.mass  leaf.area  leaf.mass
  # seed.mass  0.3125696 0.74502485 0.15007611
  # leaf.area -0.1193918 0.34758834 0.02683121
  # leaf.mass -0.0656371 0.09868565 0.43283050
  
  # OUBMestim$FinalFound$ParamsInModel$Syy
  # ##         seed.mass  leaf.area  leaf.mass
  # seed.mass  1.544998 -0.3312916 0.08572097
  # leaf.area  0.000000  1.1551896 1.26333872
  # leaf.mass  0.000000  0.0000000 1.54619107
  
  # $FinalFound$ParamsInModel$mPsi
  # ##                1         2         3        4        5         6         7         8         9 ambiguous
  # seed.mass 23.231499 33.928704 17.953335 9.193025 3.042899 0.2695936 -7.942083 -15.55207 -29.65920 -8.415247
  # leaf.area -5.772483 -7.387707 -1.226904 3.658537 8.012781 7.5781044 14.795018  17.58914  19.80078 12.235368
  # leaf.mass -4.647153 -6.177605 -1.422254 3.696470 7.089910 5.1407212 11.334586  12.47720  17.06338  1.172063
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end
  # ##   1         2         3        4         5          6          7         8         9  ambiguous
  # seed.mass 15.353043 29.503965 13.566624 4.742107 -1.170542 -0.5603294 -11.624381 -21.53320 -46.36728 -29.828578
  # leaf.area -8.537967 -8.939063 -2.786349 2.067740  6.516720  6.8953571  13.499880  15.47811  13.99326   4.643103
  # leaf.mass -7.878735 -8.125288 -3.349668 1.739933  5.199074  3.9551863   9.636278  10.01922  10.90128  -6.679029
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point
  # ##   1         2         3        4        5         6         7         8         9 ambiguous
  # seed.mass 23.231499 33.928704 17.953335 9.193025 3.042899 0.2695936 -7.942083 -15.55207 -29.65920 -8.415247
  # leaf.area -5.772483 -7.387707 -1.226904 3.658537 8.012781 7.5781044 14.795018  17.58914  19.80078 12.235368
  # leaf.mass -4.647153 -6.177605 -1.422254 3.696470 7.089910 5.1407212 11.334586  12.47720  17.06338  1.172063
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end
  # ##   1         2          3         4        5        6         7         8         9 ambiguous
  # seed.mass 31.109954 38.353444 22.3400471 13.643942 7.256340 1.099517 -4.259784 -9.570945 -12.95113 12.998084
  # leaf.area -3.006998 -5.836350  0.3325409  5.249334 9.508842 8.260852 16.090156 19.700175  25.60830 19.827633
  # leaf.mass -1.415571 -4.229921  0.5051596  5.653007 8.980747 6.326256 13.032895 14.935176  23.22547  9.023154
  
  
  
  # F. OUOU 
  start_time <- Sys.time()
  #OU1OU.seed <- as.numeric(Sys.time()); saveRDS(OU1OU.seed, "OU1OU.seed.rds") - when I saved the seed
  OU1OU.seed <- readRDS("OU1OU.seed.rds"); set.seed(OU1OU.seed)
  
  OU1OU <- mvSLOUCH::ouchModel(mvStree, mvData, predictors = c(4))  
  end_time <- Sys.time(); print(end_time - start_time ) 
  saveRDS(OU1OU, "OU1OU.rds")
  # Time difference of 10.9073 mins
  
  sink("OU1OU.output.txt"); print(OU1OU); sink()
  
  ## Information for supplement table:
  
  # OU1OU.output.txt
  # OU1OU$FinalFound$ParamsInModel$vY0
  # ##                  [,1]
  # seed.mass     0.8218965
  # leaf.area     7.2798745
  # leaf.mass     4.1867619
  # plant.height -0.6925976
  
  # OU1OU$FinalFound$ParamsInModel$A
  # ##             seed.mass   leaf.area   leaf.mass plant.height
  # seed.mass     0.43571492 -0.08054526  0.11042860   0.11175913
  # leaf.area    -0.08073013  0.40708395  0.05425403   0.07877342
  # leaf.mass    -0.01810506 -0.08196538  0.36503104   0.11353302
  # plant.height -0.03453141  0.03659200 -0.07962012   0.33938922
  
  # OU1OU$FinalFound$ParamsInModel$Syy
  # ##           seed.mass leaf.area leaf.mass plant.height
  # seed.mass     1.176919 -0.247155 0.1129184  -0.09407048
  # leaf.area     0.000000  1.050656 0.7331054   0.33729335
  # leaf.mass     0.000000  0.000000 0.9759220   0.51280890
  # plant.height  0.000000  0.000000 0.0000000   1.08925499
  
  # $FinalFound$ParamsInModel$mPsi
  # ##                reg.1
  # seed.mass     0.8218965
  # leaf.area     7.2798745
  # leaf.mass     4.1867619
  # plant.height -0.6925976
  
  # $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval
  # ##            Lower.end Estimated.Point  Upper.end
  # seed.mass     0.3941536       0.8218965  1.2496393
  # leaf.area     6.8210702       7.2798745  7.7386789
  # leaf.mass     3.7736430       4.1867619  4.5998808
  # plant.height -1.1135371      -0.6925976 -0.2716581
  
  
  
  # G. OUOU + regimes
  start_time <- Sys.time()
  #OUOUestim.seed <- as.numeric(Sys.time()); saveRDS(OUOUestim.seed, "OUOUestim.seed.rds") - when I saved the seed
  OUOUestim.seed <- readRDS("OUOUestim.seed.rds"); set.seed(OUOUestim.seed)
  
  OUOUestim <- mvSLOUCH::ouchModel(mvStree, mvData, 
                                   predictors = c(4),
                                   regimes = regimesFitch$branch_regimes)
  end_time <- Sys.time(); print(end_time - start_time ) 
  saveRDS(OUOUestim, "OUOUestim.rds")
  # Time difference of 44.56765 mins
  
  sink("OUOUestim.output.txt"); print(OUOUestim); sink()
  
  ## Information for supplement table:
  
  # OUOUestim.output.txt
  # OUOUestim$FinalFound$ParamsInModel$vY0
  # ##                  [,1]
  # seed.mass     0.3902146
  # leaf.area     7.7496013
  # leaf.mass     4.4864911
  # plant.height -0.3757983
  
  # OUOUestim$FinalFound$ParamsInModel$A
  # ##               seed.mass  leaf.area  leaf.mass plant.height
  # seed.mass     0.34980589  0.0393486 0.18559920    0.1549039
  # leaf.area    -0.03142895  0.3802934 0.11312965    0.3175805
  # leaf.mass    -0.10625031  0.0539077 0.32039229   -0.2403560
  # plant.height -0.02103761 -0.0810160 0.09393888    0.3543029
  
  # OUOUestim$FinalFound$ParamsInModel$Syy
  # ##             seed.mass  leaf.area  leaf.mass plant.height
  # seed.mass     1.141651 -0.1444279 0.08735425   -0.1978421
  # leaf.area     0.000000  0.8405613 0.68147995    0.3704064
  # leaf.mass     0.000000  0.0000000 1.02926856    0.4147407
  # plant.height  0.000000  0.0000000 0.00000000    1.1549772
  
  
  # Made from above: Basic.model.outputs.for.SI.table_short.R  Basic.model.outputs.for.SI.table_short2.R
  
  
  
  
  
  
  
  
  
  
  ## Run main mvSLOUCH models without additional customisations ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  
  ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## CUSTOMISED models ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  
  # As outlined in the Carnivoran vignette, we want to try to reach the maximum likelihood peak 
  # of each model we run (see "Numerical optimization" section of that vignette). 
  
  # A way to help achieve this by first running a simpler model, and using these as a 
  # starting point to run the 6 models of interest.
  
  # Given, for each of the 6 models we will define, we have two versions 
  # (versions where Syytype="Diagonal", and versions where Syytype="UpperTri").
  
  # Therefore, we run a set of starter models for each of them 
  # (however, Atype="DecomposablePositive", and diagA=NULL can be used for both sets)
  
  # Therefore 100 starting points will be generated for the Syytype="Diagonal" models -
  # - these will be stored in the object "OUOUstart.Diags"
  
  # and 100 starting points will be generated for the Syytype="UpperTri" models -
  # - these will be stored in the object "OUOUstart.UT"
  
  
  
  # Lets run the 100 OUOUstart.Diag models to provide 100 starting points 
  # for the six Syytype="Diagonal" models:
  
  # This just enables you to store different objects when running analyses in parallel
  multiResultClass <- function(result1=NULL,result2=NULL, result3=NULL)
  {
    me <- list(
      result1 = result1,
      result2 = result2,
      result3 = result3
    )
    ## Set the name for the class
    class(me) <- append(class(me),"multiResultClass")
    return(me)
  }
  
  
  # dir.create( paste0(".//", "_OUOU.start.Di") )
  setwd("_OUOU.start.Di")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time()
  
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  # or 2 for better laptop functioning for other tasks
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOUstart.Diags <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    result$result2 <- mvSLOUCH::ouchModel( mvStree, mvData2, regimes=regimesFitch$branch_regimes,
                                           Atype="DecomposablePositive",
                                           Syytype="Diagonal", diagA=NULL,
                                           maxiter=c(10, 100) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    return(result)
  }
  
  Sys.time() 
  
  setwd("..")
  
  
  
  OUOUstart.Diags[[1]]$result3 # Time difference of 4.356251 hours
  
  saveRDS(OUOUstart.Diags, "OUOUstart.Diags.rds")
  
  setwd("..")
  
  
  
  # Lets run the 100 OUOUstart.UT models to provide 100 starting points 
  # for the six Syytype="UpperTri" models:
  
  dir.create( paste0(".//", "OUOU.start.UT") )
  setwd("OUOU.start.UT")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time()
  
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ###### found my pc ran better if I left 2 cores free
  registerDoParallel(cores=cores)
  
  OUOUstart.UT <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    result$result2 <- mvSLOUCH::ouchModel( mvStree, mvData2, regimes=regimesFitch$branch_regimes,
                                           Atype="DecomposablePositive",
                                           Syytype="UpperTri", diagA=NULL,
                                           maxiter=c(10, 100) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOUstart.UT", i,".rds") )
    
    return(result)
  }
  
  Sys.time()
  
  setwd("..")
  
  
  
  OUOUstart.UT[[1]]$result3 # Time difference of 4.356251 hours
  
  saveRDS(OUOUstart.UT, "OUOUstart.UT.rds")
  
  setwd("..")
  
  
  
  
  
  
  
  
  
  
  ## MODEL 1  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 Diag's from the 100 OUOUstarts Diags. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  multiResultClass <- function(result1=NULL, result2=NULL, result3=NULL)
  {
    me <- list(
      result1 = result1,
      result2 = result2,
      result3 = result3
    )
    ## Set the name for the class
    class(me) <- append(class(me),"multiResultClass")
    return(me)
  }
  
  
  OUOUstart.Diags <- readRDS(".//_OUOU.start.Di//OUOUstart.Diags.rds")
  
  dir.create( paste0(".//", "_OUOU.model1.Di") )
  setwd("_OUOU.model1.Di")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model1.Diags <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.Diags.i <- OUOUstart.Diags[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="Diagonal", diagA=NULL,
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.Diags.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.Diags.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+","0","0","0"), 
                                                                              c(NA,"+",NA,NA), 
                                                                              c(NA,NA,"+",NA), 
                                                                              c(NA,NA,NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model1.Diag", i,".rds") )
    
    return(result)
  }
  Sys.time()
  
  setwd("..")
  
  OUOU.model1.Diags[[1]]$result3 # Time difference of 1.796397 hours
  
  saveRDS(OUOU.model1.Diags, "OUOU.model1.Diags.rds")
  
  
  
  OUOU.model1.Di.seeds <- vector("character")
  OUOU.model1.Di.output <- list()
  OUOU.model1.Di.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model1.Diags  # deparse(substitute(OUOU.model1.Diags))
  
  for(i in 1:length(parallel.loop.output)) { 
    
    OUOU.model1.Di.seeds[i] <- parallel.loop.output[[i]]$result1
    
    OUOU.model1.Di.output[[i]] <- parallel.loop.output[[i]]$result2 
    
    OUOU.model1.Di.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model1.Di.seeds, "OUOU.model1.Di.seeds.rds")
  saveRDS(OUOU.model1.Di.output, "OUOU.model1.Di.output.rds")
  saveRDS(OUOU.model1.Di.times, "OUOU.model1.Di.times.rds")
  
  sink("OUOU.model1.Di.seeds.txt"); print(OUOU.model1.Di.seeds); sink()
  sink("OUOU.model1.Di.output.txt"); print(OUOU.model1.Di.output); sink()
  sink("OUOU.model1.Di.times.txt"); print(OUOU.model1.Di.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 2  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 Diag's from the 100 OUOUstarts Diags. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  # Parametrization of A matrix:
  # Traits: 1. Plant height, 2. Seed size, 3. Leaf area, 4. Leaf mass
  
  #  [+ 0  0  0
  #   0 +  NA NA
  #   0 NA +  NA
  #   0 NA NA + ]
  
  # In this model, plant high does not affect leaf and seed traits which in turn are correlated with each other.
  
  OUOUstart.Diags <- readRDS(".//_OUOU.start.Di//OUOUstart.Diags.rds")
  
  dir.create( paste0(".//", "_OUOU.model2.Di") )
  setwd("_OUOU.model2.Di")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model2.Diags <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.Diags.i <- OUOUstart.Diags[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="Diagonal", diagA=NULL,
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.Diags.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.Diags.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+",0, 0, 0), 
                                                                              c(0,"+",NA,NA), 
                                                                              c(0,NA,"+",NA), 
                                                                              c(0,NA,NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model2.Diag", i,".rds") )
    
    return(result)
  }
  Sys.time() # [1] 
  
  setwd("..")
  
  saveRDS(OUOU.model2.Diags, "OUOU.model2.Diags.rds")
  
  
  
  OUOU.model2.Di.seeds <- vector("character")
  OUOU.model2.Di.output <- list()
  OUOU.model2.Di.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model2.Diags  # deparse(substitute(OUOU.model2.Diags))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model2.Di.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model2.Di.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model2.Di.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model2.Di.seeds, "OUOU.model2.Di.seeds.rds")
  saveRDS(OUOU.model2.Di.output, "OUOU.model2.Di.output.rds")
  saveRDS(OUOU.model2.Di.times, "OUOU.model2.Di.times.rds")
  
  sink("OUOU.model2.Di.seeds.txt"); print(OUOU.model2.Di.seeds); sink()
  sink("OUOU.model2.Di.output.txt"); print(OUOU.model2.Di.output); sink()
  sink("OUOU.model2.Di.times.txt"); print(OUOU.model2.Di.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 3  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 Diag's from the 100 OUOUstarts Diags. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  # Parametrization of A matrix:
  # Traits: 1. Plant height, 2. Seed size, 3. Leaf area, 4. Leaf mass
  
  #   [+ 0  0  0
  #   NA +  0  0
  #   0  0  +  NA
  #   0  0  NA + ]
  
  # In this model, plant high influences only seed size, but not leaf traits that evolve independently.
  
  OUOUstart.Diags <- readRDS(".//_OUOU.start.Di//OUOUstart.Diags.rds")
  
  dir.create( paste0(".//", "_OUOU.model3.Di") )
  setwd("_OUOU.model3.Di")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model3.Diags <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.Diags.i <- OUOUstart.Diags[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="Diagonal", diagA=NULL,
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.Diags.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.Diags.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+","0","0","0"), 
                                                                              c(NA, "+","0","0"), 
                                                                              c("0","0","+",NA), 
                                                                              c("0","0",NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model3.Diag", i,".rds") )
    
    return(result)
  }
  Sys.time()
  
  setwd("..")
  
  saveRDS(OUOU.model3.Diags, "OUOU.model3.Diags.rds")
  
  
  
  OUOU.model3.Di.seeds <- vector("character")
  OUOU.model3.Di.output <- list()
  OUOU.model3.Di.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model3.Diags  # deparse(substitute(OUOU.model3.Diags))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model3.Di.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model3.Di.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model3.Di.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model3.Di.seeds, "OUOU.model3.Di.seeds.rds")
  saveRDS(OUOU.model3.Di.output, "OUOU.model3.Di.output.rds")
  saveRDS(OUOU.model3.Di.times, "OUOU.model3.Di.times.rds")
  
  sink("OUOU.model3.Di.seeds.txt"); print(OUOU.model3.Di.seeds); sink()
  sink("OUOU.model3.Di.output.txt"); print(OUOU.model3.Di.output); sink()
  sink("OUOU.model3.Di.times.txt"); print(OUOU.model3.Di.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 4  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 Diag's from the 100 OUOUstarts Diags. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  # Parametrization of A matrix:
  # Traits: 1. Plant height, 2. Seed size, 3. Leaf area, 4. Leaf mass
  
  #   1. 2. 3. 4.
  #  [+  0  0  0
  #   0  +  0  0
  #   NA 0  +  NA
  #   NA 0  NA + ]
  # In this model, plant high influences only leaf traits, but not seed trait that evolves independently.
  
  OUOUstart.Diags <- readRDS(".//_OUOU.start.Di//OUOUstart.Diags.rds")
  
  dir.create( paste0(".//", "_OUOU.model4.Di") )
  setwd("_OUOU.model4.Di")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model4.Diags <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.Diags.i <- OUOUstart.Diags[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="Diagonal", diagA=NULL,
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.Diags.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.Diags.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+","0","0","0"), 
                                                                              c("0","+","0","0"), 
                                                                              c(NA,"0","+",NA), 
                                                                              c(NA,"0",NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model4.Diag", i,".rds") )
    
    return(result)
  }
  Sys.time() 
  
  setwd("..")
  
  saveRDS(OUOU.model4.Diags, "OUOU.model4.Diags.rds")
  
  
  
  OUOU.model4.Di.seeds <- vector("character")
  OUOU.model4.Di.output <- list()
  OUOU.model4.Di.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model4.Diags  # deparse(substitute(OUOU.model4.Diags))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model4.Di.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model4.Di.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model4.Di.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model4.Di.seeds, "OUOU.model4.Di.seeds.rds")
  saveRDS(OUOU.model4.Di.output, "OUOU.model4.Di.output.rds")
  saveRDS(OUOU.model4.Di.times, "OUOU.model4.Di.times.rds")
  
  sink("OUOU.model4.Di.seeds.txt"); print(OUOU.model4.Di.seeds); sink()
  sink("OUOU.model4.Di.output.txt"); print(OUOU.model4.Di.output); sink()
  sink("OUOU.model4.Di.times.txt"); print(OUOU.model4.Di.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 5    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 Diag's from the 100 OUOUstarts Diags. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  # Parametrization of A matrix:
  # Traits: 1. Plant height, 2. Seed size, 3. Leaf area, 4. Leaf mass
  
  #  [+ 0 0 0
  #   0 + 0 0
  #   0 0 + 0
  #   0 0 0 + ]  
  
  multiResultClass <- function(result1=NULL,result2=NULL, result3=NULL)
  {
    me <- list(
      result1 = result1,
      result2 = result2,
      result3 = result3
    )
    ## Set the name for the class
    class(me) <- append(class(me),"multiResultClass")
    return(me)
  }
  
  
  OUOUstart.Diags <- readRDS(".//_OUOU.start.Di//OUOUstart.Diags.rds")
  
  dir.create( paste0(".//", "_OUOU.model5.Di") )
  setwd("_OUOU.model5.Di")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model5.Diags <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.Diags.i <- OUOUstart.Diags[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="Diagonal", diagA=NULL,
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.Diags.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.Diags.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+","0","0","0"), 
                                                                              c("0","+","0","0"), 
                                                                              c("0","0","+","0"), 
                                                                              c("0","0","0","+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model5.Diag", i,".rds") )
    
    return(result)
  }
  Sys.time() # [1] 
  
  setwd("..")
  
  
  saveRDS(OUOU.model5.Diags, "OUOU.model5.Diags.rds")
  
  
  
  OUOU.model5.Di.seeds <- vector("character")
  OUOU.model5.Di.output <- list()
  OUOU.model5.Di.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model5.Diags  # deparse(substitute(OUOU.model5.Diags))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model5.Di.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model5.Di.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model5.Di.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model5.Di.seeds, "OUOU.model5.Di.seeds.rds")
  saveRDS(OUOU.model5.Di.output, "OUOU.model5.Di.output.rds")
  saveRDS(OUOU.model5.Di.times, "OUOU.model5.Di.times.rds")
  
  sink("OUOU.model5.Di.seeds.txt"); print(OUOU.model5.Di.seeds); sink()
  sink("OUOU.model5.Di.output.txt"); print(OUOU.model5.Di.output); sink()
  sink("OUOU.model5.Di.times.txt"); print(OUOU.model5.Di.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 6  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 Diag's from the 100 OUOUstarts Diags. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  #   [+ NA NA NA
  #   NA + NA NA
  #   NA NA + NA
  #   NA NA NA + ]
  
  # Can be set within the function with DiagA=Positive
  
  OUOUstart.Diags <- readRDS(".//_OUOU.start.Di//OUOUstart.Diags.rds")
  
  dir.create( paste0(".//", "_OUOU.model6.Di") )
  setwd("_OUOU.model6.Di")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model6.Diags <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.Diags.i <- OUOUstart.Diags[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="Diagonal", 
                                          diagA="Positive", 
                                          # repeats=, # If you do one at a time, you can save seeds
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.Diags.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.Diags.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=NULL)
    
    # Could chose to do this instead of setting diagA=Positive:
    
    # parameter_signs=list( signsA=rbind( c("+",NA,NA,NA), 
    #                                     c(NA,"+",NA,NA), 
    #                                     c(NA,NA,"+",NA), 
    #                                     c(NA,NA,NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model6.Diag", i,".rds") )
    
    return(result)
  }
  Sys.time() # [1] 
  
  setwd("..")
  
  saveRDS(OUOU.model6.Diags, "OUOU.model6.Diags.rds")
  
  
  
  OUOU.model6.Di.seeds <- vector("character")
  OUOU.model6.Di.output <- list()
  OUOU.model6.Di.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model6.Diags  # deparse(substitute(OUOU.model6.Diags))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model6.Di.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model6.Di.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model6.Di.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model6.Di.seeds, "OUOU.model6.Di.seeds.rds")
  saveRDS(OUOU.model6.Di.output, "OUOU.model6.Di.output.rds")
  saveRDS(OUOU.model6.Di.times, "OUOU.model6.Di.times.rds")
  
  sink("OUOU.model6.Di.seeds.txt"); print(OUOU.model6.Di.seeds); sink()
  sink("OUOU.model6.Di.output.txt"); print(OUOU.model6.Di.output); sink()
  sink("OUOU.model6.Di.times.txt"); print(OUOU.model6.Di.times); sink()
  
  setwd("..")
  
  
  
  
  
  # ~~~~~~~~~~~~~~~~~~~ NOW THE UPPER TRI RUNS ~~~~~~~~~~~~~~~~~~~
  # ~~~~~~~~~~~~~~~~~~~ NOW THE UPPER TRI RUNS ~~~~~~~~~~~~~~~~~~~
  # ~~~~~~~~~~~~~~~~~~~ NOW THE UPPER TRI RUNS ~~~~~~~~~~~~~~~~~~~
  
  
  ## MODEL 1  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 UT's from the 100 OUOUstarts UT. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  multiResultClass <- function(result1=NULL,result2=NULL, result3=NULL)
  {
    me <- list(
      result1 = result1,
      result2 = result2,
      result3 = result3
    )
    ## Set the name for the class
    class(me) <- append(class(me),"multiResultClass")
    return(me)
  }
  
  
  OUOUstart.UT <- readRDS(".//OUOU.start.UT//OUOUstart.UT.rds")
  
  dir.create( paste0(".//", "OUOU.model1.UT") )
  setwd("OUOU.model1.UT")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model1.UT <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.UT.i <- OUOUstart.UT[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="UpperTri", diagA=NULL, 
                                          # repeats=, # If you do one at a time, you can save seeds
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.UT.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.UT.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+","0","0","0"), 
                                                                              c(NA,"+",NA,NA), 
                                                                              c(NA,NA,"+",NA), 
                                                                              c(NA,NA,NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model1.UT", i,".rds") )
    
    return(result)
  }
  Sys.time() 
  
  setwd("..")
  
  saveRDS(OUOU.model1.UT, "OUOU.model1.UT.rds")
  
  
  
  OUOU.model1.UT.seeds <- vector("character")
  OUOU.model1.UT.output <- list()
  OUOU.model1.UT.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model1.UT  # deparse(substitute(OUOU.model1.UT))
  
  for(i in 1:length(parallel.loop.output)) { 
    
    OUOU.model1.UT.seeds[i] <- parallel.loop.output[[i]]$result1
    
    OUOU.model1.UT.output[[i]] <- parallel.loop.output[[i]]$result2 
    
    OUOU.model1.UT.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model1.UT.seeds, "OUOU.model1.UT.seeds.rds")
  saveRDS(OUOU.model1.UT.output, "OUOU.model1.UT.output.rds")
  saveRDS(OUOU.model1.UT.times, "OUOU.model1.UT.times.rds")
  
  sink("OUOU.model1.UT.seeds.txt"); print(OUOU.model1.UT.seeds); sink()
  sink("OUOU.model1.UT.output.txt"); print(OUOU.model1.UT.output); sink()
  sink("OUOU.model1.UT.times.txt"); print(OUOU.model1.UT.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 2  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 UT's from the 100 OUOUstarts UT. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  OUOUstart.UT <- readRDS(".//OUOU.start.UT//OUOUstart.UT.rds")
  
  dir.create( paste0(".//", "OUOU.model2.UT") )
  setwd("OUOU.model2.UT")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model2.UT <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.UT.i <- OUOUstart.UT[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="UpperTri", diagA=NULL, 
                                          # repeats=, # If you do one at a time, you can save seeds
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.UT.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.UT.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+",0, 0, 0), 
                                                                              c(0,"+",NA,NA), 
                                                                              c(0,NA,"+",NA), 
                                                                              c(0,NA,NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model2.UT", i,".rds") )
    
    return(result)
  }
  Sys.time() # [1] 
  
  setwd("..")
  
  saveRDS(OUOU.model2.UT, "OUOU.model2.UT.rds")
  
  
  
  OUOU.model2.UT.seeds <- vector("character")
  OUOU.model2.UT.output <- list()
  OUOU.model2.UT.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model2.UT  # deparse(substitute(OUOU.model2.UT))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model2.UT.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model2.UT.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model2.UT.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model2.UT.seeds, "OUOU.model2.UT.seeds.rds")
  saveRDS(OUOU.model2.UT.output, "OUOU.model2.UT.output.rds")
  saveRDS(OUOU.model2.UT.times, "OUOU.model2.UT.times.rds")
  
  sink("OUOU.model2.UT.seeds.txt"); print(OUOU.model2.UT.seeds); sink()
  sink("OUOU.model2.UT.output.txt"); print(OUOU.model2.UT.output); sink()
  sink("OUOU.model2.UT.times.txt"); print(OUOU.model2.UT.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 3  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 UT's from the 100 OUOUstarts UT. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  OUOUstart.UT <- readRDS(".//OUOU.start.UT//OUOUstart.UT.rds")
  
  dir.create( paste0(".//", "OUOU.model3.UT") )
  setwd("OUOU.model3.UT")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model3.UT <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.UT.i <- OUOUstart.UT[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="UpperTri", diagA=NULL, 
                                          # repeats=, # If you do one at a time, you can save seeds
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.UT.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.UT.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+","0","0","0"), 
                                                                              c(NA, "+","0","0"), 
                                                                              c("0","0","+",NA), 
                                                                              c("0","0",NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model3.UT", i,".rds") )
    
    return(result)
  }
  Sys.time()
  
  setwd("..")
  
  saveRDS(OUOU.model3.UT, "OUOU.model3.UT.rds")
  
  
  
  OUOU.model3.UT.seeds <- vector("character")
  OUOU.model3.UT.output <- list()
  OUOU.model3.UT.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model3.UT  # deparse(substitute(OUOU.model3.UT))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model3.UT.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model3.UT.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model3.UT.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model3.UT.seeds, "OUOU.model3.UT.seeds.rds")
  saveRDS(OUOU.model3.UT.output, "OUOU.model3.UT.output.rds")
  saveRDS(OUOU.model3.UT.times, "OUOU.model3.UT.times.rds")
  
  sink("OUOU.model3.UT.seeds.txt"); print(OUOU.model3.UT.seeds); sink()
  sink("OUOU.model3.UT.output.txt"); print(OUOU.model3.UT.output); sink()
  sink("OUOU.model3.UT.times.txt"); print(OUOU.model3.UT.times); sink()
  
  setwd("..")
  
  
  
  
  ## MODEL 4  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 UT's from the 100 OUOUstarts UT. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  OUOUstart.UT <- readRDS(".//OUOU.start.UT//OUOUstart.UT.rds")
  
  dir.create( paste0(".//", "OUOU.model4.UT") )
  setwd("OUOU.model4.UT")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model4.UT <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.UT.i <- OUOUstart.UT[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="UpperTri", diagA=NULL, 
                                          # repeats=, # If you do one at a time, you can save seeds
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.UT.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.UT.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+","0","0","0"), 
                                                                              c("0","+","0","0"), 
                                                                              c(NA,"0","+",NA), 
                                                                              c(NA,"0",NA,"+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model4.UT", i,".rds") )
    
    return(result)
  }
  Sys.time() # [1] 
  
  setwd("..")
  
  saveRDS(OUOU.model4.UT, "OUOU.model4.UT.rds")
  
  
  
  OUOU.model4.UT.seeds <- vector("character")
  OUOU.model4.UT.output <- list()
  OUOU.model4.UT.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model4.UT  # deparse(substitute(OUOU.model4.UT))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model4.UT.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model4.UT.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model4.UT.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model4.UT.seeds, "OUOU.model4.UT.seeds.rds")
  saveRDS(OUOU.model4.UT.output, "OUOU.model4.UT.output.rds")
  saveRDS(OUOU.model4.UT.times, "OUOU.model4.UT.times.rds")
  
  sink("OUOU.model4.UT.seeds.txt"); print(OUOU.model4.UT.seeds); sink()
  sink("OUOU.model4.UT.output.txt"); print(OUOU.model4.UT.output); sink()
  sink("OUOU.model4.UT.times.txt"); print(OUOU.model4.UT.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 5 UT  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 UT's from the 100 OUOUstarts UT. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  multiResultClass <- function(result1=NULL,result2=NULL, result3=NULL)
  {
    me <- list(
      result1 = result1,
      result2 = result2,
      result3 = result3
    )
    ## Set the name for the class
    class(me) <- append(class(me),"multiResultClass")
    return(me)
  }
  
  
  OUOUstart.UT <- readRDS(".//OUOU.start.UT//OUOUstart.UT.rds")
  
  dir.create( paste0(".//", "OUOU.model5.UT") )
  setwd("OUOU.model5.UT")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model5.UT <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.UT.i <- OUOUstart.UT[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
                                          Atype="Any", 
                                          Syytype="UpperTri", diagA=NULL, 
                                          # repeats=, # If you do one at a time, you can save seeds
                                          maxiter=c(10, 100), 
                                          start_point_for_optim=list(
                                            A=OUOUstart.UT.i$FinalFound$ParamsInModel$A, 
                                            Syy=OUOUstart.UT.i$FinalFound$ParamsInModel$Syy), 
                                          parameter_signs=list( signsA=rbind( c("+","0","0","0"), 
                                                                              c("0","+","0","0"), 
                                                                              c("0","0","+","0"), 
                                                                              c("0","0","0","+") ) ) )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model5.UT", i,".rds") )
    
    return(result)
  }
  Sys.time() # [1] 
  
  setwd("..")
  
  saveRDS(OUOU.model5.UT, "OUOU.model5.UT.rds")
  
  
  
  OUOU.model5.UT.seeds <- vector("character")
  OUOU.model5.UT.output <- list()
  OUOU.model5.UT.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model5.UT  # deparse(substitute(OUOU.model5.UT))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model5.UT.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model5.UT.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model5.UT.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model5.UT.seeds, "OUOU.model5.UT.seeds.rds")
  saveRDS(OUOU.model5.UT.output, "OUOU.model5.UT.output.rds")
  saveRDS(OUOU.model5.UT.times, "OUOU.model5.UT.times.rds")
  
  sink("OUOU.model5.UT.seeds.txt"); print(OUOU.model5.UT.seeds); sink()
  sink("OUOU.model5.UT.output.txt"); print(OUOU.model5.UT.output); sink()
  sink("OUOU.model5.UT.times.txt"); print(OUOU.model5.UT.times); sink()
  
  setwd("..")
  
  
  
  ## MODEL 6  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run 100 Model 1 UT's from the 100 OUOUstarts UT. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  OUOUstart.UT <- readRDS(".//OUOU.start.UT//OUOUstart.UT.rds")
  
  dir.create( paste0(".//", "OUOU.model6.UT") )
  setwd("OUOU.model6.UT")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  OUOU.model6.UT <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Grab the OUOUstart you need to obtain its output
    OUOUstart.UT.i <- OUOUstart.UT[[i]]$result2
    
    result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes,
                                          Atype="Any",
                                          Syytype="UpperTri", 
                                          diagA="Positive",
                                          # repeats=, # If you do one at a time, you can save seeds
                                          maxiter=c(10, 100),
                                          start_point_for_optim=list(
                                            A=OUOUstart.UT.i$FinalFound$ParamsInModel$A,
                                            Syy=OUOUstart.UT.i$FinalFound$ParamsInModel$Syy),
                                          parameter_signs=NULL )
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("OUOU.model6.UT", i,".rds") )
    
    return(result)
  }
  Sys.time() # [1] 
  
  setwd("..")
  
  saveRDS(OUOU.model6.UT, "OUOU.model6.UT.rds")
  
  
  
  OUOU.model6.UT.seeds <- vector("character")
  OUOU.model6.UT.output <- list()
  OUOU.model6.UT.times <- vector("numeric")
  
  parallel.loop.output <- OUOU.model6.UT  # deparse(substitute(OUOU.model6.UT))
  
  for(i in 1:length(parallel.loop.output)) { 
    OUOU.model6.UT.seeds[i] <- parallel.loop.output[[i]]$result1
    OUOU.model6.UT.output[[i]] <- parallel.loop.output[[i]]$result2 
    OUOU.model6.UT.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(OUOU.model6.UT.seeds, "OUOU.model6.UT.seeds.rds")
  saveRDS(OUOU.model6.UT.output, "OUOU.model6.UT.output.rds")
  saveRDS(OUOU.model6.UT.times, "OUOU.model6.UT.times.rds")
  
  sink("OUOU.model6.UT.seeds.txt"); print(OUOU.model6.UT.seeds); sink()
  sink("OUOU.model6.UT.output.txt"); print(OUOU.model6.UT.output); sink()
  sink("OUOU.model6.UT.times.txt"); print(OUOU.model6.UT.times); sink()
  
  
  setwd("..")
  
  
  ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## CUSTOMISED models END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  
  
  
}










# Load the files that were generated above
if(runtype = "load.previous.outputs") {  # "load.previous.outputs" or "novel.run" 
  
  
  
  ## If you want to load models you have run  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Load models
  
  
  # A. mvBM (multivariate Brownian motion)
  BM1 <- readRDS("BM1.rds")

  # B. mvOU (multivariate  OU)
  OU1 <- readRDS("OU1.rds")

  # C. mvOU + regimes
  OUestim <- readRDS("OUestim.rds")

  # D. OUBM
  OU1BM <- readRDS("OU1BM.rds")

  # E. OUBM + regimes
  OUBMestim <- readRDS("OUBMestim .rds")

  # F. OUOU
  OU1OU <- readRDS("OU1OU.rds")

  # G. OUOU + regimes
  OUOUestim <- readRDS("OUOUestim.rds")
  
  
  OUOUstart.Diags <- readRDS(".//_OUOU.start.Di//OUOUstart.Diags.rds")
  
  
  OUOUstart.UT <- readRDS(".//OUOU.start.UT//OUOUstart.UT.rds")
  
  
  ## MODEL 1  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model1.Di.output <- readRDS(".//_OUOU.model1.Di//OUOU.model1.output.rds")

  ## MODEL 2b  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model2.Di.output <- readRDS(".//_OUOU.model2.Di//OUOU.model2.Di.output.rds")

  ## MODEL 3b  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model3.Di.output <- readRDS(".//_OUOU.model3.Di//OUOU.model3.Di.output.rds")

  ## MODEL 4b  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model4.Di.output <- readRDS(".//_OUOU.model4.Di//OUOU.model4.Di.output.rds")

  ## MODEL 5 UT  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model5.Di.output <- readRDS(".//_OUOU.model5.Di//OUOU.model5.Di.output.rds")

  ## MODEL 6  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model6.Di.output <- readRDS(".//_OUOU.model6.Di//OUOU.model6.Di.output.rds")


  ## MODEL 1  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model1.UT.output <- readRDS(".//OUOU.model1.UT//OUOU.model1.UT.output.rds")

  ## MODEL 2b  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model2.UT.output <- readRDS(".//OUOU.model2.UT//OUOU.model2.UT.output.rds")

  ## MODEL 3b  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model3.UT.output <- readRDS(".//OUOU.model3.UT//OUOU.model3.UT.output.rds")

  ## MODEL 4  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model4.UT.output <- readRDS(".//OUOU.model4.UT//OUOU.model4.UT.output.rds")

  ## MODEL 5  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model5.UT.output <- readRDS(".//OUOU.model5.UT//OUOU.model5.UT.output.rds")

  ## MODEL 6  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  OUOU.model6.UT.output <- readRDS(".//OUOU.model6.UT//OUOU.model6.UT.output.rds")
  
  
  # Load models
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  
  
  } 










## Harvest key information from all runs of every model ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Obtain these variables for each model

# $LogLik 
# $dof
# $m2loglik
# $aic
# $aic.c    
# $bic
# $RSS$R2   

All.models <- c("BM1", "OU1", "OUestim", "OU1BM", "OUBMestim", "OU1OU", "OUOUestim",
                "OUOU.model1.Di.output", "OUOU.model2.Di.output", "OUOU.model3.Di.output",
                "OUOU.model4.Di.output", "OUOU.model5.Di.output", "OUOU.model6.Di.output", 
                "OUOU.model1.UT.output", "OUOU.model2.UT.output", "OUOU.model3.UT.output",
                "OUOU.model4.UT.output", "OUOU.model5.UT.output", "OUOU.model6.UT.output")

# A loop of me harvesting the outputs from all the above models
# makes an object called - All.ouputs.4.each.model - I then use this to extract 
# the lowest AIC run for each model
All.ouputs.4.each.model <- list()

for(i in 1:length(All.models)) {  # i=1   i=2
  
  print( paste("i", i) )
  
  # Original model object
  MODEL <- get( All.models[i] )
  
  # Grab model
  # Models of length 2 just have parameters
  # Models > 2 (all 100 here) have each model within [[ ]]
  
  # If have length of 2, and neither [[1]]$ParamSummary$aic.c  or [[1]]$FinalFound$ParamSummary$aic.c work
  # then there really us JUST ONE model
  if( length(MODEL) == 2 & # is TRUE
      #is.null(MODEL[1]$ParamSummary$aic.c) == TRUE & # if not present i.e. TRUE
      #is.null(MODEL[1]$FinalFound$ParamSummary$aic.c) == TRUE
      is.list(MODEL[[1]][[1]]) == FALSE ) { 
    # the element within the element is not a list (i.e. there is actually only one model run)
    
    How.many.models <- 1 # Then yes, you just have one model
    Model.within.list <- list()
    Model.within.list[[1]] <- MODEL
    MODEL <- Model.within.list # Now it will behave like Models with many runs
    
  } else { # You actually have 2 models
    How.many.models <- 2
  }
  
  # If something has more models...
  if( length(MODEL) > 2) {
    How.many.models <- length(MODEL)
  } 
  
  
  ## -~ Now harvest variables from all version of each model ~~~~~~~~~~~~~~~~~~~~~~~~~~~
  LogLiklihood.4.1.model <- vector("numeric")
  DOF.4.1.model <- vector("numeric")
  M2LogLiklihood.4.1.model <- vector("numeric") 
  AIC.4.1.model <- vector("numeric")
  AICc.4.1.model <- vector("numeric")
  BIC.4.1.model <- vector("numeric")
  Rsquared.4.1.model <- vector("numeric")
  
  #
  
  for(j in 1:How.many.models) {  # j=1
    
    print( paste("j", j) )
    
    # If BM1 do one thing.....
    if(All.models[i] == "BM1") { # if TRUE
      
      ### Obtain the following from both of these models:
      LogLiklihood.4.1.model[j] <- MODEL[[j]]$ParamSummary$LogLik ## Likelihood of best fitting model:
      DOF.4.1.model[j] <- MODEL[[j]]$ParamSummary$dof
      M2LogLiklihood.4.1.model[j] <- MODEL[[j]]$ParamSummary$m2loglik
      AIC.4.1.model[j] <- MODEL[[j]]$ParamSummary$aic
      AICc.4.1.model[j] <- MODEL[[j]]$ParamSummary$aic.c    ## AICc of best fitting model:
      BIC.4.1.model[j] <- MODEL[[j]]$ParamSummary$bic
      Rsquared.4.1.model[j] <- MODEL[[j]]$ParamSummary$RSS$R2   ## R2 of best fitting model:
      
    } else { # i.e. if not BM1, you grab result via 
      
      LogLiklihood.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$LogLik ## Likelihood of best fitting model:
      DOF.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$dof
      M2LogLiklihood.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$m2loglik
      AIC.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$aic
      AICc.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$aic.c    ## AICc of best fitting model:
      BIC.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$bic
      Rsquared.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$RSS$R2   ## R2 of best fitting model:
      
    } # else { # i.e. if not BM1, you grab result via 
    
    
  } # for(j in 1:length(How.many.models)) { 
  
  
  ##
  ## Now you have all the metrics you want from all versions of the model of interest
  Model.store <- list()
  
  Model.store[[1]] <- LogLiklihood.4.1.model    
  Model.store[[2]] <- DOF.4.1.model             
  Model.store[[3]] <- M2LogLiklihood.4.1.model 
  Model.store[[4]] <- AIC.4.1.model            
  Model.store[[5]] <- AICc.4.1.model          
  Model.store[[6]] <- BIC.4.1.model             
  Model.store[[7]] <- Rsquared.4.1.model
  
  names(Model.store) <- c("LogLiklihood.4.1.model", "DOF.4.1.model", "M2LogLiklihoods.4.1.model", 
                          "AIC.4.1.model", "AICc.4.1.model", "BIC.4.1.model", "Rsquared.4.1.model")        
  
  # All.ouputs.4.each.model <- list()
  All.ouputs.4.each.model[[i]] <- Model.store
  
} # for(i in 1:length(All.models)) {  # i=1

names(All.ouputs.4.each.model) <- All.models

if(runtype = "novel.run") { saveRDS(All.ouputs.4.each.model, "All.ouputs.4.each.model_firstlook.rds") }  # "load.previous.outputs" or "novel.run" 






## Save key outputs for all the main models in their respective folders
library(rlist)
# setwd("D:\\Dropbox\\216.Large.plant.example") # Set to wherever you have placed the folder on your PC)

OUOU.models <- c("OUOU.model1.Di.output", "OUOU.model2.Di.output", "OUOU.model3.Di.output",
                 "OUOU.model4.Di.output", "OUOU.model5.Di.output", "OUOU.model6.Di.output", 
                 "OUOU.model1.UT.output", "OUOU.model2.UT.output", "OUOU.model3.UT.output",
                 "OUOU.model4.UT.output", "OUOU.model5.UT.output", "OUOU.model6.UT.output")

folder.paths <- c("_OUOU.model1.Di", "_OUOU.model2.Di", "_OUOU.model3.Di", 
                  "_OUOU.model4.Di", "_OUOU.model5.Di", "_OUOU.model6.Di",
                  "OUOU.model1.UT", "OUOU.model2.UT", "OUOU.model3.UT", 
                  "OUOU.model4.UT", "OUOU.model5.UT", "OUOU.model6.UT")

key.param.tabs.all.models <- list()

for(i in 1:length(OUOU.models)) { # i=1
  
  # Grab model i
  model.i.key.params <- All.ouputs.4.each.model[OUOU.models[i]]
  
  # Combine its output, add model information 
  model.i.key.params.table <- list.cbind(model.i.key.params[[1]])
  model.i.key.params.table <- cbind(rep( OUOU.models[i], nrow(model.i.key.params.table)), 
                                    1:nrow(model.i.key.params.table), 
                                    model.i.key.params.table)
  model.i.key.params.table <- as.data.frame(model.i.key.params.table)
  colnames(model.i.key.params.table) <- c("Model.name", "Model.number", 
                                          "LogLiklihood", "DOF", "M2LogLiklihoods",
                                          "AIC", "AICc", "BIC", "Rsquared")
  
  model.i.key.params.table$Model.name <- as.character(model.i.key.params.table$Model.name) # Convert one variable to numeric
  
  fix <- c(2:length(model.i.key.params.table))                      # Specify columns you want to change
  model.i.key.params.table[ , fix] <- apply(model.i.key.params.table[ , fix], 2,    # Specify own function within apply
                                            function(x) as.numeric(as.character(x)))
  # str(model.i.key.params.table)
  
  # Order it by AICc and save  the model specific output to it's folder
  model.i.key.params.table <- model.i.key.params.table[ order( model.i.key.params.table$AICc), ]
  # Careful not to overwrite with this part...if you have already run the script once...
  
  if(runtype = "novel.run") { 
    
    write.csv( model.i.key.params.table, paste0( ".//", folder.paths[i], "//", "key.paramaters.csv" ), row.names=FALSE )
    saveRDS( model.i.key.params.table, paste0( ".//", folder.paths[i], "//", "key.paramaters.rds" ) )
    
    }  # "load.previous.outputs" or "novel.run" 
  
  
  # Add this to a mega file
  key.param.tabs.all.models[[i]] <- model.i.key.params.table
  
}

# Combine, order, and save the mega output
key.param.tabs.all.models.comb <- do.call(rbind, key.param.tabs.all.models)
str(key.param.tabs.all.models.comb)
key.param.tabs.all.models.comb <- key.param.tabs.all.models.comb[ order( key.param.tabs.all.models.comb$AICc), ]

if(runtype = "novel.run") { 
  
  write.csv( key.param.tabs.all.models.comb, "key.param.tabs.all.models_firstlook.csv", row.names=FALSE )
  saveRDS( key.param.tabs.all.models.comb, "key.param.tabs.all.models_firstlook.rds" )
  
  }  # "load.previous.outputs" or "novel.run" 




## Examine these outputs from your models (e.g. look at key.param.tabs.all.models_firstlook.csv)


# We found that the model with the lowest AICc was within model 6 with Σyy diagonal. 
# However, we then noticed that the best model for the alternative model 6 (with Σyy upper–triangular) possessed a 
# lower log-likelihood score than model 6 Σyy diagonal, despite the former being more complex. 

# Model.name	          Model.number LogLiklihood	DOF	M2LogLiklihoods	AIC	        AICc	      BIC	        Rsquared
# OUOU.model6.Di.output	79	         -9271.035517	60	18542.07103	    18662.07103	18663.55072	19053.19855	0.102184147
# 
# OUOU.model6.UT.output 92	        -35792.64542	66	71585.29085	    71717.29085	71719.08077	72147.53111	0.008681844

# This should not happen if things are running correctly, and therefore informs us that the numerical optimizer 
# has failed, having arrived at a worse local optimum of the log-likelihood surface than the simpler model. 

# We therefore decided to use model 6 Σyy diagonal output as a starting point for 
# a new run of model 6 Σyy upper–triangular (using the start_point_for_optim=list argument in ouchModel().

# This is run below:



if(runtype = "novel.run") { 
  
  
  ## MODEL 6  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ## Run a Model UT, using the best Model 6 Diagonal Syy as a starting point ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  start_time <- Sys.time()
  
  seed <- as.numeric(Sys.time())
  set.seed(seed) # it needs to be saved
  
  # Grab the OUOUstart you need to obtain its output
  OUOU.model6.UT_reanalysis <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes,
                                                   Atype="Any",
                                                   Syytype="UpperTri", 
                                                   diagA="Positive",
                                                   maxiter=c(10, 100),
                                                   start_point_for_optim=list(
                                                     A=OUOU.model6.Di.output[[79]]$FinalFound$ParamsInModel$A,
                                                     Syy=OUOU.model6.Di.output[[79]]$FinalFound$ParamsInModel$Syy),
                                                   parameter_signs=NULL)
  
  end_time <- Sys.time(); end_time - start_time # Time difference of 3.11661 hours
  
  saveRDS(seed, "seed_OUOU.model6.UT_reanalysis.rds")
  saveRDS(OUOU.model6.UT_reanalysis, "OUOU.model6.UT_reanalysis.rds")
  sink("OUOU.model6.UT_reanalysis.output.txt"); print(OUOU.model6.UT_reanalysis); sink()
  
  
  }  # "load.previous.outputs" or "novel.run" 


if(runtype = "load.previous.outputs") {  OUOU.model6.UT_reanalysis <- readRDS("OUOU.model6.UT_reanalysis.rds")  }  # "load.previous.outputs" or "novel.run" 


# OUOU.model6.UT_reanalysis.output select outputs.R

# OUOU.model6.UT_reanalysis.output
# $FinalFound$ParamsInModel$vY0
# ##                  [,1]
# plant.height -0.64421980
# seed.mass    -0.03456367
# leaf.area     7.05776503
# leaf.mass     3.81628988

# $FinalFound$ParamsInModel$A
# ##           plant.height  seed.mass  leaf.area  leaf.mass
# plant.height    69.769179 -6.2292137 -1.0521482  -3.904829
# seed.mass        7.522467 21.1358335 -0.4038856   4.208800
# leaf.area       10.081599  0.4776791 47.7794519 -13.486645
# leaf.mass        6.178898 -1.8974837 -5.8048322  30.935553

# $FinalFound$ParamsInModel$Syy
# ##            plant.height  seed.mass  leaf.area leaf.mass
# plant.height     10.48734  0.2236248  0.7520609  5.288048
# seed.mass         0.00000 13.3912797 -0.8704203  3.187047
# leaf.area         0.00000  0.0000000  9.1636602 11.737491
# leaf.mass         0.00000  0.0000000  0.0000000 12.968969

# $FinalFound$ParamsInModel$mPsi
# ##                1          2         3          4          5           6          7          8          9 ambiguous
# plant.height -1.794485 -1.6772871 -1.226414 -0.8198210 -0.3593010 -0.64421980 -0.2504362 -0.2936231 -0.5459189 -1.224828
# seed.mass    -2.002929 -0.9944204 -0.631878  0.2563999  0.5446443 -0.03456367  0.9046385  0.9084421 -0.5931383 -1.607115
# leaf.area     4.156059  4.6655786  5.848904  6.3214404  6.6656811  7.05776503  7.6804370  8.4272891  7.4212524  4.718261
# leaf.mass     1.408102  1.6812127  2.827140  3.3334513  3.6617489  3.81628988  4.5167630  5.1302196  4.1362553  1.095669

# $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end
# ##                1         2         3          4          5          6          7          8         9  ambiguous
# plant.height -2.2373583 -1.870613 -1.392171 -0.9973372 -0.5310899 -0.7817258 -0.4102585 -0.5578971 -1.206750 -2.4788868
# seed.mass    -3.0060077 -1.429818 -1.018667 -0.1555356  0.1370559 -0.3277558  0.5418006  0.3015927 -1.990914 -3.8480224
# leaf.area     3.3907320  4.331674  5.559137  6.0111999  6.3626898  6.8278444  7.4044931  7.9682387  6.314619  2.8527504
# leaf.mass     0.5907367  1.324046  2.515059  2.9999360  3.3341501  3.5736393  4.2211914  4.6377549  2.974039 -0.7841674

# $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point
# ##                1          2         3          4          5           6          7          8          9 ambiguous
# plant.height -1.794485 -1.6772871 -1.226414 -0.8198210 -0.3593010 -0.64421980 -0.2504362 -0.2936231 -0.5459189 -1.224828
# seed.mass    -2.002929 -0.9944204 -0.631878  0.2563999  0.5446443 -0.03456367  0.9046385  0.9084421 -0.5931383 -1.607115
# leaf.area     4.156059  4.6655786  5.848904  6.3214404  6.6656811  7.05776503  7.6804370  8.4272891  7.4212524  4.718261
# leaf.mass     1.408102  1.6812127  2.827140  3.3334513  3.6617489  3.81628988  4.5167630  5.1302196  4.1362553  1.095669

# $FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end
# ##                1          2          3          4          5          6           7           8         9  ambiguous
# plant.height -1.3516112 -1.4839614 -1.0606566 -0.6423049 -0.1875120 -0.5067138 -0.09061385 -0.02934903 0.1149118 0.02923028
# seed.mass    -0.9998499 -0.5590224 -0.2450892  0.6683354  0.9522328  0.2586284  1.26747638  1.51529156 0.8046370 0.63379340
# leaf.area     4.9213852  4.9994836  6.1386703  6.6316810  6.9686724  7.2876857  7.95638087  8.88633956 8.5278857 6.58377223
# leaf.mass     2.2254678  2.0383794  3.1392221  3.6669666  3.9893477  4.0589405  4.81233459  5.62268421 5.2984718 2.97550542










## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## PLOT OPTIMA of best model: OUOU.model6.UT_reanalysis ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

OUOU.model6.UT_reanalysis$FinalFound$ParamsInModel$mPsi

# Well, first plot these CIs
Mod.6.trait.optima <- OUOU.model6.UT_reanalysis$FinalFound$ParamsInModel$mPsi
# Mod.6.trait.optima
#                      1          2         3          4          5           6          7          8          9 ambiguous
# plant.height -1.794485 -1.6772871 -1.226414 -0.8198210 -0.3593010 -0.64421980 -0.2504362 -0.2936231 -0.5459189 -1.224828
# seed.mass    -2.002929 -0.9944204 -0.631878  0.2563999  0.5446443 -0.03456367  0.9046385  0.9084421 -0.5931383 -1.607115
# leaf.area     4.156059  4.6655786  5.848904  6.3214404  6.6656811  7.05776503  7.6804370  8.4272891  7.4212524  4.718261
# leaf.mass     1.408102  1.6812127  2.827140  3.3334513  3.6617489  3.81628988  4.5167630  5.1302196  4.1362553  1.095669


# tidyr::gather()
library(tidyr)
library(ggplot2)
# mini_iris <- iris[c(1, 51, 101), ]
# str(mini_iris)
# # 'data.frame':	3 obs. of  5 variables:
# # $ Sepal.Length: num  5.1 7 6.3
# # $ Sepal.Width : num  3.5 3.2 3.3
# # $ Petal.Length: num  1.4 4.7 6
# # $ Petal.Width : num  0.2 1.4 2.5
# # $ Species     : Factor w/ 3 levels "setosa","versicolor",..: 1 2 3
# # gather Sepal.Length, Sepal.Width, Petal.Length, Petal.Width
# tidyr::gather(mini_iris, key = "flower_att", 
#               value = "measurement",
#               Sepal.Length, Sepal.Width, Petal.Length, Petal.Width)


Mod.6.trait.optima <- as.data.frame(Mod.6.trait.optima) # get into same format as iris data
colnames(Mod.6.trait.optima) <- c("E1","E2","E3","E4","E5","E6","E7","E8","E9","ambiguous")
Mod.6.trait.optima$Trait <- rownames(Mod.6.trait.optima)

Mod.6.trait.optima <- tidyr::gather(Mod.6.trait.optima, # dataframe to convert
                                    key = "EllenVal", # Category that united the column names
                                    value = "Optima_logged.values", # what to call the numeric values
                                    - Trait, # any columns you want to appear on their own
                                    E1,E2,E3,E4,E5,E6,E7,E8,E9,ambiguous) # name the columns

# Units:                 leaf area plant height  seed mass leaf mass
#                          (mm2)       (m)         (mg)      (mg)

# Rename all those methods to short version for plot   &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Mod.6.trait.optima$Trait <- car::recode( Mod.6.trait.optima$Trait, 
                                         "'plant.height'='plant height(m)';
                                         'seed.mass'='seed mass(mg)';
                                         'leaf.mass'='leaf mass(mg)';
                                         'leaf.area'='leaf area(mm2)'" )

DFs1 <- data.frame(
  Ecology=factor(colnames(OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point)),
  Trait= rep( "plant height(m)", length(colnames(OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point)) ),
  Estimated.Point=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point["plant.height",],
  upper=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end["plant.height",],
  lower=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end["plant.height",]
)

DFs2 <- data.frame(
  Ecology=factor(colnames(OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point)),
  Trait= rep( "seed mass(mg)", length(colnames(OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point)) ),
  Estimated.Point=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point["seed.mass",],
  upper=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end["seed.mass",],
  lower=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end["seed.mass",]
)

DFs3 <- data.frame(
  Ecology=factor(colnames(OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point)),
  Trait= rep( "leaf area(mm2)", length(colnames(OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point)) ),
  Estimated.Point=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point["leaf.area",],
  upper=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end["leaf.area",],
  lower=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end["leaf.area",]
)

DFs4 <- data.frame(
  Ecology=factor(colnames(OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point)),
  Trait= rep( "leaf mass(mg)", length(colnames(OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point)) ),
  Estimated.Point=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point["leaf.mass",],
  upper=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end["leaf.mass",],
  lower=OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end["leaf.mass",]
)


DFs <- rbind(DFs1, DFs2, DFs3, DFs4)


grouping.mean.size.by.hab <- ggplot( DFs, aes(x=Ecology, y=Estimated.Point, group=Trait, color=Trait) ) + 
  geom_point(size=2.5) + 
  geom_errorbar(ggplot2::aes(ymin=lower, ymax=upper), width=0.2) + 
  theme_bw() +                                                                            
  theme( axis.line = element_line(size=0.1) ) +     
  ## X axis related                                                                                
  theme( axis.title.x = element_blank() ) +                                                                              
  theme( axis.ticks.x = element_line(size=0.4) ) +                                                                              
  theme( axis.text.x = element_text(size=10) ) +                                                            
  theme( axis.title.x = element_text(size=10, margin = margin(t=8, r=0, b=0, l=0)) ) + 
  xlab( paste0("Ellenberg values") ) + 
  scale_x_discrete(position = "bottom")  +                                        
  ## Y axis related                                                                       
  theme( axis.ticks.y = element_line(size=0.4) ) +                                                                          
  theme( axis.text.y = element_text(size=10) ) +                        
  theme( axis.title.y = element_text(size=10, margin = margin(t=0, r=8, b=0, l=0)) ) +      
  ylab( paste0("log(optimum value)") ) +  
  scale_y_continuous(breaks = round( seq( -4, 9, by=1), 1) ) + 
  
  ## Strip                                                                                                            
  theme( panel.border = element_blank() ) +                                         
  theme( panel.grid.major = element_blank() ) + # panel.grid.major                                                                                
  theme( panel.grid.minor = element_blank() ) + # panel.grid.minor                                                                                
  theme( panel.grid.minor.x = element_blank() ) + # panel.grid.minor.x                                                                                
  theme( panel.grid.minor.y = element_blank() ) + # panel.grid.minor.y                                                                                
  theme( panel.ontop = element_blank() ) + # panel.ontop                                                                                
  theme( plot.background = element_blank() ) + # plot.background                                                                                
  
  ## Legend                                                                                
  theme( legend.title = element_blank() ) + #theme(legend.title = elemen
  theme( legend.text = element_text(size=10) ) +                                                     
  theme( legend.spacing.x = unit(0.2, 'cm') ) +                                                
  theme( legend.position = "bottom", legend.box = "horizontal", legend.direction = "horizontal" ) + 
  theme( legend.margin = margin(t=-5, r=0, b=0, l=0)) +
  guides(fill = guide_legend(nrow = 1)) # 1   fill=guide_legend(title="New Legend Title")                                                                                                                                               
  #theme( legend.key = element_rect(fill=NA) ) # or fill = 'pink'                                                         
  #guides(colour = guide_legend(override.aes = list(size=4))) + # Change the size of the symbols in the legend only    

if(runtype = "novel.run") { 
  
  ggsave( paste("Optima_model6UT_reanalysis", ".pdf", sep=""), # paste(dat.name, "Optima", ".pdf", sep="_")                                                                                  
          grouping.mean.size.by.hab, width=190, height=150, units="mm", useDingbats=FALSE ) # width=210, height=297  A4 
  
  }  # "load.previous.outputs" or "novel.run" 











## Harvest key information from all runs of every model 2nd look ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

All.models <- c("BM1", "OU1", "OUestim", "OU1BM", "OUBMestim", "OU1OU", "OUOUestim",
                "OUOU.model1.Di.output", "OUOU.model2.Di.output", "OUOU.model3.Di.output",
                "OUOU.model4.Di.output", "OUOU.model5.Di.output", "OUOU.model6.Di.output", 
                "OUOU.model1.UT.output", "OUOU.model2.UT.output", "OUOU.model3.UT.output",
                "OUOU.model4.UT.output", "OUOU.model5.UT.output", "OUOU.model6.UT.output",
                "OUOU.model6.UT_reanalysis")

# A loop of me harvesting the outputs from all the above models
# makes an object called - All.ouputs.4.each.model - I then use this to extract the lowest AIC for each model
All.ouputs.4.each.model <- list()

for(i in 1:length(All.models)) {  # i=1   i=2
  
  print( paste("i", i) )
  print( All.models[i] )
  # Original model object
  MODEL <- get( All.models[i] )
  
  # Grab model
  # Models of length 2 just have parameters
  # Models > 2 (all 100 here) have each model within [[ ]]
  
  # If have length of 2, and neither [[1]]$ParamSummary$aic.c  or [[1]]$FinalFound$ParamSummary$aic.c work
  # then there really us JUST ONE model
  if( length(MODEL) == 2 & # is TRUE
      #is.null(MODEL[1]$ParamSummary$aic.c) == TRUE & # if not present i.e. TRUE
      #is.null(MODEL[1]$FinalFound$ParamSummary$aic.c) == TRUE
      is.list(MODEL[[1]][[1]]) == FALSE ) { 
    # the element within the element is not a list (i.e. there is actually only one model run)
    
    How.many.models <- 1 # Then yes, you just have one model
    Model.within.list <- list()
    Model.within.list[[1]] <- MODEL
    MODEL <- Model.within.list # Now it will behave like Models with many runs
    
  } else { # You actually have 2 models
    How.many.models <- 2
  }
  
  # If something has more models...
  if( length(MODEL) > 2) {
    How.many.models <- length(MODEL)
  } 
  
  
  ## -~ Now harvest variables from all version of each model ~~~~~~~~~~~~~~~~~~~~~~~~~~~
  LogLiklihood.4.1.model <- vector("numeric")
  DOF.4.1.model <- vector("numeric")
  M2LogLiklihood.4.1.model <- vector("numeric") 
  AIC.4.1.model <- vector("numeric")
  AICc.4.1.model <- vector("numeric")
  BIC.4.1.model <- vector("numeric")
  Rsquared.4.1.model <- vector("numeric")
  
  #
  
  for(j in 1:How.many.models) {  # j=1
    
    #print( paste("j", j) )
    print( paste("No of models j", j) )
    
    # If BM1 do one thing.....
    if(All.models[i] == "BM1") { # if TRUE
      
      ### Obtain the following from both of these models:
      LogLiklihood.4.1.model[j] <- MODEL[[j]]$ParamSummary$LogLik ## Likelihood of best fitting model:
      DOF.4.1.model[j] <- MODEL[[j]]$ParamSummary$dof
      M2LogLiklihood.4.1.model[j] <- MODEL[[j]]$ParamSummary$m2loglik
      AIC.4.1.model[j] <- MODEL[[j]]$ParamSummary$aic
      AICc.4.1.model[j] <- MODEL[[j]]$ParamSummary$aic.c    ## AICc of best fitting model:
      BIC.4.1.model[j] <- MODEL[[j]]$ParamSummary$bic
      Rsquared.4.1.model[j] <- MODEL[[j]]$ParamSummary$RSS$R2   ## R2 of best fitting model:
      
    } else { # i.e. if not BM1, you grab result via 
      
      LogLiklihood.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$LogLik ## Likelihood of best fitting model:
      DOF.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$dof
      M2LogLiklihood.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$m2loglik
      AIC.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$aic
      AICc.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$aic.c    ## AICc of best fitting model:
      BIC.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$bic
      Rsquared.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$RSS$R2   ## R2 of best fitting model:
      
    } # else { # i.e. if not BM1, you grab result via 
    
  } # for(j in 1:length(How.many.models)) { 
  
  ##
  ## Now you have all the metrics you want from all versions of the model of interest
  Model.store <- list()
  
  Model.store[[1]] <- LogLiklihood.4.1.model    
  Model.store[[2]] <- DOF.4.1.model             
  Model.store[[3]] <- M2LogLiklihood.4.1.model 
  Model.store[[4]] <- AIC.4.1.model            
  Model.store[[5]] <- AICc.4.1.model          
  Model.store[[6]] <- BIC.4.1.model             
  Model.store[[7]] <- Rsquared.4.1.model
  
  names(Model.store) <- c("LogLiklihood.4.1.model", "DOF.4.1.model", "M2LogLiklihoods.4.1.model", 
                          "AIC.4.1.model", "AICc.4.1.model", "BIC.4.1.model", "Rsquared.4.1.model")        
  
  # All.ouputs.4.each.model <- list()
  All.ouputs.4.each.model[[i]] <- Model.store
  
} # for(i in 1:length(All.models)) {  # i=1

names(All.ouputs.4.each.model) <- All.models


if(runtype = "novel.run") { 
  
  saveRDS(All.ouputs.4.each.model, "All.ouputs.4.each.model_secondlook.rds")
  
  }  # "load.previous.outputs" or "novel.run" 





# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## Save key outputs for all the main models in their respective folders

OUOU.models <- c("BM1", "OU1", "OUestim", "OU1BM", "OUBMestim", "OU1OU", "OUOUestim",
                 "OUOU.model1.Di.output", "OUOU.model2.Di.output", "OUOU.model3.Di.output",
                 "OUOU.model4.Di.output", "OUOU.model5.Di.output", "OUOU.model6.Di.output", 
                 "OUOU.model1.UT.output", "OUOU.model2.UT.output", "OUOU.model3.UT.output",
                 "OUOU.model4.UT.output", "OUOU.model5.UT.output", "OUOU.model6.UT.output",
                 "OUOU.model6.UT_reanalysis")
# OUOU.model6.UT_reanalysis - don't need to add this one, just a single model

## No need to save individual outputs in this second run
# folder.paths <- c("_OUOU.model1.Di", "_OUOU.model2.Di", "_OUOU.model3.Di", 
#                   "_OUOU.model4.Di", "_OUOU.model5.Di", "_OUOU.model6.Di",
#                   "OUOU.model1.UT", "OUOU.model2.UT", "OUOU.model3.UT", 
#                   "OUOU.model4.UT", "OUOU.model5.UT", "OUOU.model6.UT")

key.param.tabs.all.models <- list()

for(i in 1:length(OUOU.models)) { # i=1
  
  # Grab model i
  model.i.key.params <- All.ouputs.4.each.model[OUOU.models[i]]
  
  # Combine its output, add model information 
  model.i.key.params.table <- list.cbind(model.i.key.params[[1]])
  model.i.key.params.table <- cbind(rep( OUOU.models[i], nrow(model.i.key.params.table)), 
                                    1:nrow(model.i.key.params.table), 
                                    model.i.key.params.table)
  model.i.key.params.table <- as.data.frame(model.i.key.params.table)
  colnames(model.i.key.params.table) <- c("Model.name", "Model.number", 
                                          "LogLiklihood", "DOF", "M2LogLiklihoods",
                                          "AIC", "AICc", "BIC", "Rsquared")
  
  model.i.key.params.table$Model.name <- as.character(model.i.key.params.table$Model.name) # Convert one variable to numeric
  
  fix <- c(2:length(model.i.key.params.table))                                      # Specify columns you want to change
  model.i.key.params.table[ , fix] <- apply(model.i.key.params.table[ , fix], 2,    # Specify own function within apply
                                            function(x) as.numeric(as.character(x)))
  # str(model.i.key.params.table)
  
  # Order it by AICc and save  the model specific output to it's folder
  model.i.key.params.table <- model.i.key.params.table[ order( model.i.key.params.table$AICc), ]
  # No need to save indivual outputs in this second run
  #write.csv( model.i.key.params.table, paste0( ".//", folder.paths[i], "//", "key.paramaters.csv" ), row.names=FALSE )
  #saveRDS( model.i.key.params.table, paste0( ".//", folder.paths[i], "//", "key.paramaters.rds" ) )
  
  # Add this to a mega file
  key.param.tabs.all.models[[i]] <- model.i.key.params.table
  
}

# Combine, order, and save the mega output
key.param.tabs.all.models.comb <- do.call(rbind, key.param.tabs.all.models)
str(key.param.tabs.all.models.comb)
key.param.tabs.all.models.comb <- key.param.tabs.all.models.comb[ order( key.param.tabs.all.models.comb$AICc), ]


if(runtype = "novel.run") { 
  
  write.csv( key.param.tabs.all.models.comb, "key.param.tabs.all.models_secondlook.csv", row.names=FALSE )
  saveRDS( key.param.tabs.all.models.comb, "key.param.tabs.all.models_secondlook.rds" )
  
  }  # "load.previous.outputs" or "novel.run" 







# TABLE 1 SI info table
################### Prune to best models only

OUOU.models <- c("BM1", "OU1", "OUestim", "OU1BM", "OUBMestim", "OU1OU", "OUOUestim",
                 "OUOU.model1.Di.output", "OUOU.model2.Di.output", "OUOU.model3.Di.output",
                 "OUOU.model4.Di.output", "OUOU.model5.Di.output", "OUOU.model6.Di.output", 
                 "OUOU.model1.UT.output", "OUOU.model2.UT.output", "OUOU.model3.UT.output",
                 "OUOU.model4.UT.output", "OUOU.model5.UT.output", "OUOU.model6.UT.output",
                 "OUOU.model6.UT_reanalysis")

data.frame.best.models <- data.frame()

for(i in 1:length(OUOU.models)) { # i=1
  
  # Grab model i
  model.i.key.params <- key.param.tabs.all.models.comb[key.param.tabs.all.models.comb$Model.name == OUOU.models[i], ]
  
  # Grab smallest
  min.AICc <- min( model.i.key.params$AICc )
  
  # Save output for best model
  which.run.was.min <- match( min.AICc, model.i.key.params$AICc )
  
  data.frame.best.models <- rbind(data.frame.best.models, model.i.key.params[which.run.was.min, ])
  
}

str(data.frame.best.models)
data.frame.best.models <- data.frame.best.models[ order( data.frame.best.models$AICc), ]


if(runtype = "novel.run") { 
  
  write.csv( data.frame.best.models, "key.param.data.frame.best.models.csv", row.names=FALSE )
  saveRDS( data.frame.best.models, "key.param.data.frame.best.models.rds" )
  
}  # "load.previous.outputs" or "novel.run" 








# Main customized model output

## Look through all models ---
All.models <- c("OUOU.model1.Di.output", "OUOU.model2.Di.output", "OUOU.model3.Di.output",
                "OUOU.model4.Di.output", "OUOU.model5.Di.output", "OUOU.model6.Di.output", 
                "OUOU.model1.UT.output", "OUOU.model2.UT.output", "OUOU.model3.UT.output",
                "OUOU.model4.UT.output", "OUOU.model5.UT.output", "OUOU.model6.UT.output")

## A loop of me harvesting the outputs from all the above models
# makes an object called - All.ouputs.4.each.model - I then use this to extract the lowest AIC for each model
All.ouputs.4.each.model <- list()

for(i in 1:length(All.models)) {  # i=1   i=2
  
  print( paste("i", i) )
  
  # Original model object
  MODEL <- get( All.models[i] )
  
  # Grab model
  # Models of length 2 just have parameters
  # Models > 2 (all 100 here) have each model within [[ ]]
  
  # If have length of 2, and neither [[1]]$ParamSummary$aic.c  or [[1]]$FinalFound$ParamSummary$aic.c work
  # then there really us JUST ONE model
  if( length(MODEL) == 2 & # is TRUE
      #is.null(MODEL[1]$ParamSummary$aic.c) == TRUE & # if not present i.e. TRUE
      #is.null(MODEL[1]$FinalFound$ParamSummary$aic.c) == TRUE
      is.list(MODEL[[1]][[1]]) == FALSE ) { # the element within the element is not a list (i.e. there is actually only one model run)
    
    How.many.models <- 1 # Then yes, you just have one model
    Model.within.list <- list()
    Model.within.list[[1]] <- MODEL
    MODEL <- Model.within.list # Now it will behave like Models with many runs
    
  } else { # You actually have 2 models
    How.many.models <- 2
  }
  
  # If something has more models...
  if( length(MODEL) > 2) {
    How.many.models <- length(MODEL)
  } 
  
  ## -~ Now harvest variables from all version of each model ~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Liklihoods.4.1.model <- vector("numeric")
  AICc.4.1.model  <- vector("numeric")
  Rsquared.4.1.model  <- vector("numeric")
  
  for(j in 1:How.many.models) {  # j=1
    
    print( paste("j", j) )
    
    # If BM1 do one thing.....
    if(All.models[i] == "BM1") { # if TRUE
      
      ### Obtain the following from both of these models:
      
      ## Likelihood of best fitting model:
      Liklihoods.4.1.model[j] <- MODEL[[j]]$ParamSummary$LogLik
      
      ## AICc of best fitting model:
      AICc.4.1.model[j] <- MODEL[[j]]$ParamSummary$aic.c
      
      ## R2 of best fitting model:
      Rsquared.4.1.model[j] <- MODEL[[j]]$ParamSummary$RSS$R2
      
    } else { # i.e. if not BM1, you grab result via 
      
      ### Obtain the following from both of these models:
      
      ## Likelihood of best fitting model:
      Liklihoods.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$LogLik
      
      ## AICc of best fitting model:
      AICc.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$aic.c
      
      ## R2 of best fitting model:
      Rsquared.4.1.model[j] <- MODEL[[j]]$FinalFound$ParamSummary$RSS$R2
      
    } # else { # i.e. if not BM1, you grab result via 
    
  } # for(j in 1:length(How.many.models)) { 
  
  ##
  ## Now you have all the metrics you want from all versions of the model of interest
  Model.store <- list()
  
  Model.store[[1]] <- Liklihoods.4.1.model
  Model.store[[2]] <- AICc.4.1.model
  Model.store[[3]] <- Rsquared.4.1.model
  
  names(Model.store) <- c("Liklihoods.4.1.model", "AICc.4.1.model", "Rsquared.4.1.model")
  
  # All.ouputs.4.each.model <- list()
  All.ouputs.4.each.model[[i]] <- Model.store
  
} # for(i in 1:length(All.models)) {  # i=1
names(All.ouputs.4.each.model) <- All.models




# Then make code to loop through this list and grab whatever you need, i.e., highest aic of 
# each model, highest aic overall, etc.
Model.names <- vector("character")
Model.min.AICc <- vector("numeric")
#Best.output.for.each.model <- list()

if(runtype = "novel.run") { 
  
  # Print and save ALL output for this minimum run
  sink( paste0( "Main.model.outputs.for.SI.table_short2.txt" ) )
  
}  # "load.previous.outputs" or "novel.run" 


for(i in 1:length(All.ouputs.4.each.model)) { # i=8
  
  # Get name
  Model.names[i] <- names(All.ouputs.4.each.model)[i] 
  print( names(All.ouputs.4.each.model)[i] )  
  
  # Get min
  Model.min.AICc[i] <- min( All.ouputs.4.each.model[[i]]$AICc.4.1.model )
  
  # Save output for best model
  which.run.was.min <- match( min(All.ouputs.4.each.model[[i]]$AICc.4.1.model), All.ouputs.4.each.model[[i]]$AICc.4.1.model )
  
  
  ## Items to write to text file:
  # 1. 
  paste0( "AICc_", round(Model.min.AICc[i]), "_", names(All.ouputs.4.each.model)[i], "_Best Model_", ".txt" )
  
  # 2.
  paste0( names(All.ouputs.4.each.model)[i], "_Best Model" )
  
  # 3.
  print("FinalFound$ParamsInModel$vY0")
  print( get( names(All.ouputs.4.each.model)[i] )[[which.run.was.min]]$FinalFound$ParamsInModel$vY0 )
  print( "                 " )
  
  print("FinalFound$ParamsInModel$A")
  print( get( names(All.ouputs.4.each.model)[i] )[[which.run.was.min]]$FinalFound$ParamsInModel$A )
  print( "                 " )
  
  print("FinalFound$ParamsInModel$Syy")
  print( get( names(All.ouputs.4.each.model)[i] )[[which.run.was.min]]$FinalFound$ParamsInModel$Syy )
  print( "                 " )
  print( "                 " )
  
  print("FinalFound$ParamsInModel$mPsi")
  print( get( names(All.ouputs.4.each.model)[i] )[[which.run.was.min]]$FinalFound$ParamsInModel$mPsi )
  print( "                 " )
  print( "                 " )
  
  print("FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end")
  print( get( names(All.ouputs.4.each.model)[i] )[[which.run.was.min]]$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Lower.end )
  print( "                 " )
  print( "                 " )
  
  print("FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point")
  print( get( names(All.ouputs.4.each.model)[i] )[[which.run.was.min]]$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Estimated.Point )
  print( "                 " )
  print( "                 " )
  
  print("FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end")
  print( get( names(All.ouputs.4.each.model)[i] )[[which.run.was.min]]$FinalFound$ParamSummary$confidence.interval$regression.summary$mPsi.regression.confidence.interval$Upper.end )
  print( "                 " )
  print( "                 " )
  
  #Best.output.for.each.model[[length(Best.output.for.each.model)+1]] <- get( print( names(All.ouputs.4.each.model)[i] ) )[[which.run.was.min]]
  #names(Best.output.for.each.model)[length(Best.output.for.each.model)] <- paste0( names(All.ouputs.4.each.model)[i], "_Best Model" ) 
  
}

if(runtype = "novel.run") {  sink()  }  # "load.previous.outputs" or "novel.run" 


# ModnAICc <- data.frame(Model.names, Model.min.AICc)
# str(ModnAICc)
# colnames(ModnAICc) <- c("Model.names", "Model.min")










## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## Parametric bootstrap the best model ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


if(runtype = "novel.run") {  
  
  
  
  # library("foreach")
  # library("doParallel")
  # library("mvSLOUCH")
  # library("PCMBaseCpp")
  # library("ape")
  # library("rlist")
  
  ## -----------------------------------------------------------------------------
  # RNGversion can be used to set the random generators as they were in an earlier R version (for reproducibility).
  
  RNGversion("3.6.1") # - Sets RNG to a specific version (e.g. pick one at random, such as an older version).
  
  # The function set.seed() allows specifying a starting point in a sequence of randomly generated numbers 
  # so that a user can obtain the same outputs under a given process. For the purposes of the current example,
  # if you want to replicate the outputs below (for mvSLOUCH 2.7.2), set up the following seed:
  
  # Set a specific seed, so all analyses below can be replicated        
  # set.seed is the recommended way to specify seeds.
  set.seed(seed=5, # seed, a single value, interpreted as an integer, or NULL 
           kind = "Mersenne-Twister", # to set the kind (i.e. type) of random number generator. 
           normal.kind = "Inversion")
  
  # Now this is set, every item that is run from this point onwards should match our values.
  # We will also set values for each individual analysis, so that any specific part can be easily replicated.
  
  
  
  # The optimized speed of the new mvSLOUCH version allows obtaining confidence intervals for a variety 
  # of parameters under parametric bootstrapping.
  
  # The bootstrap function (parametric.bootstrap) uses the estimates of a fitted evolutionary model.
  # The function also requires the specification of the phylogenetic tree (phyltree), 
  # the number of bootstrap samples (numboot), and the list of estimates for which we want obtain confidence intervals (values.to.bootstrap). 
  # Other arguments for this function have been introduced before and deal with the specification of 
  # the regime (regimes, root.regime), explanatory variable (predictors), and model setting (Atype, Syytype, diagA). 
  
  # The bootstrap procedure will take some time and mvSLOUCH will print the current iteration and 
  # the elapsed time so that you can monitor its progress.
  
  # When it is completed, the resulting object (BT) will hold the simulated data and model outputs of each bootstrap replicate. 
  
  # However, here, we wanted to save a seed for every individual run of the bootstrap. Therefore, we set numboot=1, and ran
  # the replicates individually, in a parallel, in a loop.
  
  
  
  # Lets remind ourselves of the best model, OUOU.model6.UT_reanalysis 
  
  # OUOU.model6.UT_reanalysis <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes,
  #                                                  Atype="Any",
  #                                                  Syytype="UpperTri", 
  #                                                  diagA="Positive",
  #                                                  maxiter=c(10, 100),
  #                                                  start_point_for_optim=list(
  #                                                    A=OUOU.model6.Di.output[[79]]$FinalFound$ParamsInModel$A,
  #                                                    Syy=OUOU.model6.Di.output[[79]]$FinalFound$ParamsInModel$Syy),
  #                                                  parameter_signs=NULL)
  
  
  
  # Remember, this reanalysis was obtained by using the lowest AICc Model 6 with Syytype="Diagonal"
  # (OUOU.model6.Diags) as a starting point - here is just a snippet from the loop above where they were run:
  
  # OUOU.model6.Diags <- foreach(i=1:100) %dopar% {
  #   
  #   start_time <- Sys.time()
  #   
  #   result <- multiResultClass()
  #   
  #   seed <- as.numeric(Sys.time()+i)
  #   set.seed(seed) # it needs to be saved
  #   result$result1 <- seed
  #
  # # Grab the OUOUstart you need to obtain its output
  # OUOUstart.Diags.i <- OUOUstart.Diags[[i]]$result2
  
  # result$result2 <- mvSLOUCH::ouchModel(mvStree, mvData2, regimes=regimesFitch$branch_regimes, 
  #                                       Atype="Any", 
  #                                       Syytype="Diagonal", 
  #                                       diagA="Positive", 
  #                                       # repeats=, # If you do one at a time, you can save seeds
  #                                       maxiter=c(10, 100), 
  #                                       start_point_for_optim=list(
  #                                         A=OUOUstart.Diags.i$FinalFound$ParamsInModel$A, 
  #                                         Syy=OUOUstart.Diags.i$FinalFound$ParamsInModel$Syy), 
  #                                       parameter_signs=NULL)
  
  
  
  
  
  ## Now run the bootstrap - Just an example if you ran it without a loop, as in the mvSLOUCH vignette
  
  
  # BT <- mvSLOUCH::parametric.bootstrap(estimated.model = OUOU.model6.UT_reanalysis, phyltree = mvStree, 
  #                                      regimes = regimesFitch$branch_regimes,
  #                                      Atype = "Any", 
  #                                      Syytype = "UpperTri", 
  #                                      diagA = "Positive",
  #                                      values.to.bootstrap = c("mPsi", "corr.matrix", 
  #                                                              "trait.regression", 
  #                                                              "conditional.corr.matrix",
  #                                                              "phyl.halflife"),
  #                                      numboot = 100)
  
  
  
  
  
  ## Create the first set of 100 bootstraps ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  
  # If I were not running this in a parralell loop, I would run it as in the mammal vignette, by setting numoot.
  # E.g.:
  
  # BT <- mvSLOUCH::parametric.bootstrap(estimated.model = OUOU.model6.UT_reanalysis, phyltree = mvStree, 
  #                                      regimes = regimesFitch$branch_regimes,
  #                                      Atype = "Any", 
  #                                      Syytype = "UpperTri", 
  #                                      diagA = "Positive",
  #                                      values.to.bootstrap = c("mPsi", "corr.matrix", 
  #                                                              "trait.regression", 
  #                                                              "conditional.corr.matrix",
  #                                                              "phyl.halflife"),
  #                                      numboot = 100)
  
  
  # But instead...I:
  
  multiResultClass <- function(result1=NULL,result2=NULL, result3=NULL)
  {
    me <- list(
      result1 = result1,
      result2 = result2,
      result3 = result3
    )
    ## Set the name for the class
    class(me) <- append(class(me),"multiResultClass")
    return(me)
  }
  
  
  dir.create( paste0(".//", "BStrap_OUOU.model6.UT_reanalysis") )
  setwd("BStrap_OUOU.model6.UT_reanalysis")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  BStrap_OUOU.model6.UT_reanalysis <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Run the bootstrap
    result$result2 <- mvSLOUCH::parametric.bootstrap(estimated.model = OUOU.model6.UT_reanalysis, phyltree = mvStree, 
                                                     regimes = regimesFitch$branch_regimes,
                                                     Atype = "Any", 
                                                     Syytype = "UpperTri", 
                                                     diagA = "Positive",
                                                     values.to.bootstrap = c("mPsi", "corr.matrix", 
                                                                             "trait.regression", 
                                                                             "conditional.corr.matrix",
                                                                             "phyl.halflife"),
                                                     numboot = 1)
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("BStrap_OUOU.model6.UT_reanalysis", i,".rds") )
    
    return(result)
  }
  
  Sys.time()
  
  setwd("..")
  
  saveRDS(BStrap_OUOU.model6.UT_reanalysis, "BStrap_OUOU.model6.UT_reanalysis.rds")
  
  #
  
  BStrap_OUOU.model6.UT_reanalysis.seeds <- vector("character")
  BStrap_OUOU.model6.UT_reanalysis.output <- list()
  BStrap_OUOU.model6.UT_reanalysis.times <- vector("numeric")
  
  parallel.loop.output <- BStrap_OUOU.model6.UT_reanalysis  # deparse(substitute(BStrap_OUOU.model6.UT_reanalysis))
  
  for(i in 1:length(parallel.loop.output)) { 
    BStrap_OUOU.model6.UT_reanalysis.seeds[i] <- parallel.loop.output[[i]]$result1
    BStrap_OUOU.model6.UT_reanalysis.output[[i]] <- parallel.loop.output[[i]]$result2 
    BStrap_OUOU.model6.UT_reanalysis.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(BStrap_OUOU.model6.UT_reanalysis.seeds, "BStrap_OUOU.model6.UT_reanalysis.seeds.rds")
  saveRDS(BStrap_OUOU.model6.UT_reanalysis.output, "BStrap_OUOU.model6.UT_reanalysis.output.rds")
  saveRDS(BStrap_OUOU.model6.UT_reanalysis.times, "BStrap_OUOU.model6.UT_reanalysis.times.rds")
  
  sink("BStrap_OUOU.model6.UT_reanalysis.seeds.txt"); print(BStrap_OUOU.model6.UT_reanalysis.seeds); sink()
  sink("BStrap_OUOU.model6.UT_reanalysis.output.txt"); print(BStrap_OUOU.model6.UT_reanalysis.output); sink()
  sink("BStrap_OUOU.model6.UT_reanalysis.times.txt"); print(BStrap_OUOU.model6.UT_reanalysis.times); sink()
  
  setwd("..")
  
  
  
  
  
  ## Create the first set of 100 bootstraps ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # - using Model 6 diagonal Syy model as starting point ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  multiResultClass <- function(result1=NULL,result2=NULL, result3=NULL)
  {
    me <- list(
      result1 = result1,
      result2 = result2,
      result3 = result3
    )
    ## Set the name for the class
    class(me) <- append(class(me),"multiResultClass")
    return(me)
  }
  
  
  dir.create( paste0(".//", "BStrap2_OUOU.model6.UT_reanalysis_") )
  setwd("BStrap2_OUOU.model6.UT_reanalysis_")
  dir.create( paste0(".//", "Indiv.runs") )
  setwd("Indiv.runs")
  
  
  Sys.time() # [1] 
  # detectCores() 8 for my laptop
  # cores <- detectCores() - 1  
  cores <- 6 ######
  registerDoParallel(cores=cores)
  
  BStrap2_OUOU.model6.UT_reanalysis <- foreach(i=1:100) %dopar% {
    
    start_time <- Sys.time()
    
    result <- multiResultClass()
    
    seed <- as.numeric(Sys.time()+i)
    set.seed(seed) # it needs to be saved
    result$result1 <- seed
    
    # Run the bootstrap
    result$result2 <- mvSLOUCH::parametric.bootstrap(estimated.model = OUOU.model6.UT_reanalysis, phyltree = mvStree, 
                                                     regimes = regimesFitch$branch_regimes,
                                                     Atype = "Any", 
                                                     Syytype = "UpperTri", 
                                                     diagA = "Positive",
                                                     values.to.bootstrap = c("mPsi", "corr.matrix", 
                                                                             "trait.regression", 
                                                                             "conditional.corr.matrix",
                                                                             "phyl.halflife"),
                                                     numboot = 1,
                                                     start_point_for_optim=list(
                                                       A=OUOU.model6.Di.output[[79]]$FinalFound$ParamsInModel$A, # notice this change from above
                                                       Syy=OUOU.model6.Di.output[[79]]$FinalFound$ParamsInModel$Syy), # notice this change from above
                                                     parameter_signs=NULL) # notice this change from above
    
    print( paste("loop", i, "complete"))
    
    end_time <- Sys.time(); end_time - start_time 
    print( end_time - start_time ) 
    result$result3 <- end_time - start_time 
    
    saveRDS(result, file=paste0("BStrap2_OUOU.model6.UT_reanalysis", i,".rds") )
    
    return(result)
  }
  Sys.time() # [1] 
  
  setwd("..")
  
  saveRDS(BStrap2_OUOU.model6.UT_reanalysis, "BStrap2_OUOU.model6.UT_reanalysis.rds")
  
  #
  
  BStrap2_OUOU.model6.UT_reanalysis.seeds <- vector("character")
  BStrap2_OUOU.model6.UT_reanalysis.output <- list()
  BStrap2_OUOU.model6.UT_reanalysis.times <- vector("numeric")
  
  parallel.loop.output <- BStrap2_OUOU.model6.UT_reanalysis  # deparse(substitute(BStrap2_OUOU.model6.UT_reanalysis))
  
  for(i in 1:length(parallel.loop.output)) { 
    BStrap2_OUOU.model6.UT_reanalysis.seeds[i] <- parallel.loop.output[[i]]$result1
    BStrap2_OUOU.model6.UT_reanalysis.output[[i]] <- parallel.loop.output[[i]]$result2 
    BStrap2_OUOU.model6.UT_reanalysis.times[i] <- parallel.loop.output[[i]]$result3
  }
  
  saveRDS(BStrap2_OUOU.model6.UT_reanalysis.seeds, "BStrap2_OUOU.model6.UT_reanalysis.seeds.rds")
  saveRDS(BStrap2_OUOU.model6.UT_reanalysis.output, "BStrap2_OUOU.model6.UT_reanalysis.output.rds")
  saveRDS(BStrap2_OUOU.model6.UT_reanalysis.times, "BStrap2_OUOU.model6.UT_reanalysis.times.rds")
  
  sink("BStrap2_OUOU.model6.UT_reanalysis.seeds.txt"); print(BStrap2_OUOU.model6.UT_reanalysis.seeds); sink()
  sink("BStrap2_OUOU.model6.UT_reanalysis.output.txt"); print(BStrap2_OUOU.model6.UT_reanalysis.output); sink()
  sink("BStrap2_OUOU.model6.UT_reanalysis.times.txt"); print(BStrap2_OUOU.model6.UT_reanalysis.times); sink()
  
  setwd("..")
  
  
  
}  # "load.previous.outputs" or "novel.run" 










# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Derive key metrics from bootstraps ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if(runtype = "novel.run") { 
  
  
  # dir.create( paste0(".//", "BStrap_OUOU.model6.UT_reanalysis") )
  # setwd("BStrap_OUOU.model6.UT_reanalysis")
  # dir.create( paste0(".//", "Indiv.runs") )
  # setwd("Indiv.runs")
  # setwd("..")
  # saveRDS(BStrap_OUOU.model6.UT_reanalysis, "BStrap_OUOU.model6.UT_reanalysis.rds")
  BStrap_OUOU.model6.UT_reanalysis.output <- readRDS( paste0(".//", "BStrap_OUOU.model6.UT_reanalysis//BStrap_OUOU.model6.UT_reanalysis.output.rds"), 
                                                      refhook = NULL)
  
  # dir.create( paste0(".//", "BStrap2_OUOU.model6.UT_reanalysis_") )
  # setwd("BStrap2_OUOU.model6.UT_reanalysis_")
  # dir.create( paste0(".//", "Indiv.runs") )
  # setwd("Indiv.runs")
  # setwd("..")
  # saveRDS(BStrap2_OUOU.model6.UT_reanalysis, "BStrap2_OUOU.model6.UT_reanalysis.rds")
  BStrap2_OUOU.model6.UT_reanalysis.output <- readRDS( paste0(".//", "BStrap2_OUOU.model6.UT_reanalysis_//BStrap2_OUOU.model6.UT_reanalysis.output.rds"), 
                                                       refhook = NULL)
  
  
}  # "load.previous.outputs" or "novel.run" 










# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Obtain confidence intervals from the boostrap runs


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ mPsi


# BStrap_OUOU.model6.UT_reanalysis.output ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$mPsi[[1]]
#                       1         2          3          4          5           6         7          8          9 ambiguous
# plant.height   60.07206   94.0538   39.39154   45.25714   3.897237 -0.63370143 -27.31401  -95.18587   6.893671  103.7702
# seed.mass    -179.51715 -277.7760 -118.25894 -132.39900 -11.362188 -0.02198747  79.45978  276.12123 -23.049238 -304.3749
# leaf.area     125.81938  193.9564   85.88251   97.46944  15.359207  6.82034548 -45.27283 -178.21226  22.324221  213.0087
# leaf.mass      71.86500  110.7785   49.30696   55.75949   8.476058  3.43581971 -26.26487 -103.65953  13.064542  119.5328


# Make a list of your parameter of interest (which is a matrix)
mPsi.matrix.store <- list()

for(i in 1:length(BStrap_OUOU.model6.UT_reanalysis.output)) {
  mPsi.matrix.store[[i]] <- BStrap_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$mPsi[[1]]
}

# List of your parameter of interest (which is a matrix)
param.matrices.list <- mPsi.matrix.store

# Template matrix
template.matrix <- BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$mPsi[[1]]


BTU.Mat <- rep(NA, length(as.vector(template.matrix)))
BTL.Mat <- BTU.Mat

for(i in 1:length(as.vector(template.matrix))){
  BT.Mat<-quantile(sapply(mPsi.matrix.store, function(x) x[i]), c(0.025, 0.975))
  BTL.Mat[i] <- BT.Mat[1]
  BTU.Mat[i] <- BT.Mat[2]
}

BTL.Mat <- matrix(BTL.Mat, nrow = nrow(template.matrix))
BTU.Mat <- matrix(BTU.Mat, nrow = nrow(template.matrix))

dimnames(BTL.Mat) <- dimnames(BTU.Mat) <- list(row.names(template.matrix), colnames(template.matrix))

# The lower (BTL.Mat) and upper (BTU.Mat) bounds of the 95% confidence interval for the 
# correlation matrix:
BT.Lower.CI.mPsi <- BTL.Mat
BT.Upper.CI.mPsi <- BTU.Mat


BT.Lower.CI.mPsi
BT.Upper.CI.mPsi


# BT.Lower.CI.mPsi
#                      1         2          3         4           5          6          7          8           9 ambiguous
# plant.height -10.80073 -11.02280  -8.010128 -3.707952  0.05673275 -0.9096536 -0.1776852 -2.3662296  -5.6815351 -15.05915
# seed.mass    -20.89571 -16.12506 -12.263162 -2.337081 -1.60274621 -0.8831560  1.8265631 -0.0801433 -19.1161977 -37.35587
# leaf.area    -12.29648 -11.15719  -4.255402  1.292269  4.15169097  6.8702421  7.4771881  8.5595074  -0.7116369 -23.15437
# leaf.mass    -12.01464 -12.25033  -5.365844 -1.151545  1.05125819  3.4579691  4.8629546  6.2775954  -4.6347659 -27.59498

# BT.Upper.CI.mPsi
#                       1          2         3         4        5          6         7         8         9 ambiguous
# plant.height -1.4230964 -1.8944767 -1.519602 0.8818871 4.243347 -0.1199158  4.043639  5.909911  5.651680  5.113500
# seed.mass    -1.8565784  0.7545646  0.502823 7.1066572 8.152611  0.6341745 11.114576 16.587633  7.311011  8.505829
# leaf.area     4.0790928  4.6251464  5.856558 6.8322282 8.866388  8.0946822 14.313996 23.395347 18.159521 11.473860
# leaf.mass    -0.2332081  0.5656951  2.183543 4.6135853 7.813294  4.5741827 11.009080 18.673412 13.207670  4.052783

# mvData2[,1]




# BStrap2_OUOU.model6.UT_reanalysis.output ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$mPsi[[1]]
#                   1         2          3          4          5          6          7          8          9  ambiguous
# plant.height -1.568402 -1.655219 -1.1509489 -0.6237659 -0.2832192 -0.7990058 -0.1505571 -0.2251348  0.1394310 -2.0132771
# seed.mass    -1.419005 -1.133223 -0.4470296  0.2463516  0.5604188 -0.3990421  0.7214417  1.0870931 -0.8708092 -2.0867734
# leaf.area     4.165866  4.620997  6.2355082  6.6084908  6.7894801  7.1880854  7.5847166  8.7502368  7.7682487  4.6125538
# leaf.mass     1.435330  1.692130  3.2301931  3.7205447  3.9258936  3.8551080  4.4705822  5.3055016  4.4436514  0.7697537


# Make a list of your parameter of interest (which is a matrix)
mPsi.matrix.store <- list()

for(i in 1:length(BStrap2_OUOU.model6.UT_reanalysis.output)) {
  mPsi.matrix.store[[i]] <- BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$mPsi[[1]]
}

# List of your parameter of interest (which is a matrix)
param.matrices.list <- mPsi.matrix.store

# Template matrix
template.matrix <- BStrap2_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$mPsi[[1]]


BTU.Mat <- rep(NA, length(as.vector(template.matrix)))
BTL.Mat <- BTU.Mat

for(i in 1:length(as.vector(template.matrix))){
  BT.Mat<-quantile(sapply(mPsi.matrix.store, function(x) x[i]), c(0.025, 0.975))
  BTL.Mat[i] <- BT.Mat[1]
  BTU.Mat[i] <- BT.Mat[2]
}

BTL.Mat <- matrix(BTL.Mat, nrow = nrow(template.matrix))
BTU.Mat <- matrix(BTU.Mat, nrow = nrow(template.matrix))

dimnames(BTL.Mat) <- dimnames(BTU.Mat) <- list(row.names(template.matrix), colnames(template.matrix))


# The lower (BTL.Mat) and upper (BTU.Mat) bounds of the 95% confidence interval:
BT.Lower.CI.mPsi <- BTL.Mat
BT.Upper.CI.mPsi <- BTU.Mat


BT.Lower.CI.mPsi
BT.Upper.CI.mPsi


# BT.Lower.CI.mPsi
#                       1         2         3          4          5          6          7          8         9 ambiguous
# plant.height -2.2704376 -1.895650 -1.400967 -1.0001620 -0.5242265 -0.7660805 -0.4029201 -0.4994766 -1.304082 -2.144338
# seed.mass    -3.1712394 -1.445432 -1.029206 -0.1535334  0.1770848 -0.3053162  0.5090757  0.4482647 -2.244310 -3.299219
# leaf.area     3.1914443  4.279705  5.560611  6.0221187  6.3394689  6.8443546  7.4716812  8.1342098  6.283204  2.729719
# leaf.mass     0.5238222  1.246764  2.527404  3.0119488  3.2988960  3.6007739  4.2796233  4.6652010  2.837349 -1.023412
# BT.Upper.CI.mPsi
#                       1          2          3          4          5          6           7          8           9  ambiguous
# plant.height -1.4550522 -1.5099685 -1.0591776 -0.6474169 -0.1561706 -0.5046186 -0.09828723 0.01479124 0.008342299 0.22430171
# seed.mass    -0.6751247 -0.4980257 -0.2442173  0.6651540  0.8749973  0.2361262  1.31191447 1.46230491 0.782302615 0.09528347
# leaf.area     4.8778490  4.9821900  6.1350449  6.5908740  6.9232127  7.3129414  7.98564243 8.88581353 8.440263474 6.55260217
# leaf.mass     2.2478428  1.9863321  3.1416976  3.6275217  3.9855083  4.1212997  4.81160606 5.63923494 5.192711603 2.47161173

# mvData2[,1]




# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ corr.matrix

# BStrap_OUOU.model6.UT_reanalysis.output ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Look at the output for our best model:
# BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$corr.matrix[[1]]
# ##            plant.height  seed.mass  leaf.area  leaf.mass
# plant.height    1.0000000 -0.6546328  0.8127634  0.7616439
# seed.mass      -0.6546328  1.0000000 -0.7298282 -0.7510019
# leaf.area       0.8127634 -0.7298282  1.0000000  0.6208729
# leaf.mass       0.7616439 -0.7510019  0.6208729  1.0000000


# Look at output for a single bootstrap run:
# BStrap_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$corr.matrix[[1]]
# ##           plant.height   seed.mass   leaf.area leaf.mass
# plant.height   1.00000000  0.09058636  0.24923467 0.1927374
# seed.mass      0.09058636  1.00000000 -0.03220912 0.1529768
# leaf.area      0.24923467 -0.03220912  1.00000000 0.5629821
# leaf.mass      0.19273736  0.15297682  0.56298211 1.0000000


# Make a list of your parameter of interest (which is a matrix)
corr.matrix.matrix.store <- list()

for(i in 1:length(BStrap_OUOU.model6.UT_reanalysis.output)) {
  corr.matrix.matrix.store[[i]] <- BStrap_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$corr.matrix[[1]]
}

# List of your parameter of interest (which is a matrix)
param.matrices.list <- corr.matrix.matrix.store

# Template matrix
template.matrix <- BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$corr.matrix[[1]]


BTU.Mat <- rep(NA, length(as.vector(template.matrix)))
BTL.Mat <- BTU.Mat

for(i in 1:length(as.vector(template.matrix))){
  BT.Mat <- quantile(sapply(corr.matrix.matrix.store, function(x) x[i]), c(0.025, 0.975))
  BTL.Mat[i] <- BT.Mat[1]
  BTU.Mat[i] <- BT.Mat[2]
}

BTL.Mat <- matrix(BTL.Mat, nrow = nrow(template.matrix))
BTU.Mat <- matrix(BTU.Mat, nrow = nrow(template.matrix))

dimnames(BTL.Mat) <- dimnames(BTU.Mat) <- list(row.names(template.matrix), colnames(template.matrix))

# The lower (BTL.Mat) and upper (BTU.Mat) bounds of the 95% confidence interval for the 
# correlation matrix:
BT.Lower.CI.corr.matrix <- BTL.Mat
BT.Upper.CI.corr.matrix <- BTU.Mat


BT.Lower.CI.corr.matrix
BT.Upper.CI.corr.matrix


# BT.Lower.CI.corr.matrix
# ##           plant.height   seed.mass   leaf.area  leaf.mass
# plant.height   1.00000000 -0.03851207  0.03419366 0.10691193
# seed.mass     -0.03851207  1.00000000 -0.11166825 0.02468602
# leaf.area      0.03419366 -0.11166825  1.00000000 0.24362366
# leaf.mass      0.10691193  0.02468602  0.24362366 1.00000000

# BT.Upper.CI.corr.matrix
# ##           plant.height seed.mass leaf.area leaf.mass
# plant.height    1.0000000 0.2738692 0.3275419 0.4546645
# seed.mass       0.2738692 1.0000000 0.1616240 0.3526899
# leaf.area       0.3275419 0.1616240 1.0000000 0.7213038
# leaf.mass       0.4546645 0.3526899 0.7213038 1.0000000




# BStrap2_OUOU.model6.UT_reanalysis.output ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Look at the output for our best model:
# BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$corr.matrix[[1]]
# ##            plant.height  seed.mass  leaf.area  leaf.mass
# plant.height    1.0000000 -0.6546328  0.8127634  0.7616439
# seed.mass      -0.6546328  1.0000000 -0.7298282 -0.7510019
# leaf.area       0.8127634 -0.7298282  1.0000000  0.6208729
# leaf.mass       0.7616439 -0.7510019  0.6208729  1.0000000


# Look at output for a single bootstrap run:
# BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$corr.matrix[[1]]
# ##           plant.height  seed.mass  leaf.area leaf.mass
# plant.height    1.0000000 0.16077950 0.36094296 0.4079993
# seed.mass       0.1607795 1.00000000 0.06683799 0.1413114
# leaf.area       0.3609430 0.06683799 1.00000000 0.8281161
# leaf.mass       0.4079993 0.14131140 0.82811615 1.0000000


# Make a list of your parameter of interest (which is a matrix)
corr.matrix.matrix.store <- list()

for(i in 1:length(BStrap2_OUOU.model6.UT_reanalysis.output)) {
  corr.matrix.matrix.store[[i]] <- BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$corr.matrix[[1]]
}

# List of your parameter of interest (which is a matrix)
param.matrices.list <- corr.matrix.matrix.store

# Template matrix
template.matrix <- BStrap2_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$corr.matrix[[1]]


BTU.Mat <- rep(NA, length(as.vector(template.matrix)))
BTL.Mat <- BTU.Mat

for(i in 1:length(as.vector(template.matrix))){
  BT.Mat <- quantile(sapply(corr.matrix.matrix.store, function(x) x[i]), c(0.025, 0.975))
  BTL.Mat[i] <- BT.Mat[1]
  BTU.Mat[i] <- BT.Mat[2]
}

BTL.Mat <- matrix(BTL.Mat, nrow = nrow(template.matrix))
BTU.Mat <- matrix(BTU.Mat, nrow = nrow(template.matrix))

dimnames(BTL.Mat) <- dimnames(BTU.Mat) <- list(row.names(template.matrix), colnames(template.matrix))

# The lower (BTL.Mat) and upper (BTU.Mat) bounds of the 95% confidence interval for the 
# correlation matrix:
BT.Lower.CI.corr.matrix <- BTL.Mat
BT.Upper.CI.corr.matrix <- BTU.Mat


BT.Lower.CI.corr.matrix
BT.Upper.CI.corr.matrix


# BT.Lower.CI.corr.matrix
# ##           plant.height   seed.mass   leaf.area  leaf.mass
# plant.height   1.00000000  0.07833365  0.29192305 0.32665566
# seed.mass      0.07833365  1.00000000 -0.03871368 0.07210203
# leaf.area      0.29192305 -0.03871368  1.00000000 0.79164788
# leaf.mass      0.32665566  0.07210203  0.79164788 1.00000000

# BT.Upper.CI.corr.matrix
# ##           plant.height  seed.mass  leaf.area leaf.mass
# plant.height    1.0000000 0.20633928 0.41563710 0.4584034
# seed.mass       0.2063393 1.00000000 0.09792459 0.1982963
# leaf.area       0.4156371 0.09792459 1.00000000 0.8602964
# leaf.mass       0.4584034 0.19829634 0.86029644 1.0000000




# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ halflives bootstrap CIs

BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives
#                             [,1]                 [,2]          [,3]             [,4]
# eigenvalues 10.85025110+2.76155i 10.85025110-2.76155i  2.8738965+0i -2.584564e-02+0i
# halflife     0.06388305+0.00000i  0.06388305+0.00000i  0.2411872+0i -2.681872e+01+0i
# %treeheight  6.38830543+0.00000i  6.38830543+0.00000i 24.1187248+0i -2.681872e+03+0i


# Make a list of your parameter of interest (which is a matrix)
halflives.matrix.store <- list()

for(i in 1:length(BStrap_OUOU.model6.UT_reanalysis.output)) {
  halflives.matrix.store[[i]] <- BStrap_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives
}

# List of your parameter of interest (which is a matrix)
param.matrices.list <- halflives.matrix.store

# Template matrix
template.matrix <- BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives


BTU.Mat <- rep(NA, length(as.vector(template.matrix)))
BTL.Mat <- BTU.Mat

for(i in 1:length(as.vector(template.matrix))){
  BT.Mat<-quantile(sapply(halflives.matrix.store, function(x) x[i]), c(0.025, 0.975))
  BTL.Mat[i] <- BT.Mat[1]
  BTU.Mat[i] <- BT.Mat[2]
}

BTL.Mat <- matrix(BTL.Mat, nrow = nrow(template.matrix))
BTU.Mat <- matrix(BTU.Mat, nrow = nrow(template.matrix))

dimnames(BTL.Mat) <- dimnames(BTU.Mat) <- list(row.names(template.matrix), colnames(template.matrix))


# The lower (BTL.Mat) and upper (BTU.Mat) bounds of the 95% confidence interval for the 
BT.Lower.CI.halflives <- BTL.Mat
BT.Upper.CI.halflives <- BTU.Mat


BT.Lower.CI.halflives
BT.Upper.CI.halflives


# BT.Lower.CI.halflives
# [,1]                  [,2]                  [,3]          [,4]
# eigenvalues 0.84787593+0.041382i 0.73737370+0.0220511i  0.6300247+0.1136624i  0.4385848+0i
# halflife    0.05613291+0.000000i 0.07732107+0.0000000i  0.1782325+0.0000000i  0.4686547+0i
# %treeheight 5.61329060+0.000000i 7.73210659+0.0000000i 17.8232497+0.0000000i 46.8654730+0i

# BT.Upper.CI.halflives
# [,1]                 [,2]          [,3]                   [,4]
# eigenvalues 12.5621723+1.31174i  9.2683904-0.655367i   4.365777+0i   0.8938675-0.0592195i
# halflife     0.8175162+0.00000i  0.9402793+0.000000i   1.100197+0i   1.2982591+0.0000000i
# %treeheight 81.7516250+0.00000i 94.0279321+0.000000i 110.019720+0i 129.8259119+0.0000000i


#


# BStrap2_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives ~~~~~~~~~~~~~~~~~~

BStrap2_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives
#                       [,1]           [,2]                 [,3]                 [,4]
# eigenvalues 48.21347832+0i 42.29565065+0i 21.85387472+1.24552i 21.85387472-1.24552i
# halflife     0.01437663+0i  0.01638814+0i  0.03171736+0.00000i  0.03171736+0.00000i
# %treeheight  1.43766267+0i  1.63881432+0i  3.17173586+0.00000i  3.17173586+0.00000i


# Make a list of your parameter of interest (which is a matrix)
halflives.matrix.store <- list()

for(i in 1:length(BStrap2_OUOU.model6.UT_reanalysis.output)) {
  halflives.matrix.store[[i]] <- BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives
}

# List of your parameter of interest (which is a matrix)
param.matrices.list <- halflives.matrix.store

# Template matrix
template.matrix <- BStrap2_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives


BTU.Mat <- rep(NA, length(as.vector(template.matrix)))
BTL.Mat <- BTU.Mat

for(i in 1:length(as.vector(template.matrix))){
  BT.Mat<-quantile(sapply(halflives.matrix.store, function(x) x[i]), c(0.025, 0.975))
  BTL.Mat[i] <- BT.Mat[1]
  BTU.Mat[i] <- BT.Mat[2]
}

BTL.Mat <- matrix(BTL.Mat, nrow = nrow(template.matrix))
BTU.Mat <- matrix(BTU.Mat, nrow = nrow(template.matrix))

dimnames(BTL.Mat) <- dimnames(BTU.Mat) <- list(row.names(template.matrix), colnames(template.matrix))


# The lower (BTL.Mat) and upper (BTU.Mat) bounds of the 95% confidence interval for the 
BT.Lower.CI.halflives <- BTL.Mat
BT.Upper.CI.halflives <- BTU.Mat


BT.Lower.CI.halflives
BT.Upper.CI.halflives


# BT.Lower.CI.halflives
# [,1]           [,2]                 [,3]           [,4]
# eigenvalues 45.98779664+2.22117i 39.97204693+0i 20.56118790+2.57106i 17.66493095+0i
# halflife     0.01143646+0.00000i  0.01351405+0i  0.02353371+0.00000i  0.02753179+0i
# %treeheight  1.14364599+0.00000i  1.35140527+0i  2.35337130+0.00000i  2.75317895+0i

# BT.Upper.CI.halflives
# [,1]                 [,2]           [,3]                [,4]
# eigenvalues 60.60901200+0i 51.29136878-3.26242i 29.45576954+0i 25.17659668-0.8757i
# halflife     0.01507248+0i  0.01734082+0.00000i  0.03371149+0i  0.03923977+0.0000i
# %treeheight  1.50724820+0i  1.73408170+0.00000i  3.37114927+0i  3.92397698+0.0000i






# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ trait.regression bootstrap CIs


# BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$trait.regression[[1]]

# [[1]]         seed.mass leaf.area leaf.mass
# plant.height 0.06862465 0.3418518 0.4232571
# 
# [[2]]     plant.height  leaf.area leaf.mass
# seed.mass     0.775343 -0.8858323 -1.406704
# 
# [[3]]     plant.height  seed.mass  leaf.mass
# leaf.area      1.33628 -0.3064766 -0.4262237
# 
# [[4]]     plant.height  seed.mass  leaf.area
# leaf.mass    0.7969032 -0.2344177 -0.2052955

numboot <- length(BStrap_OUOU.model6.UT_reanalysis.output)

# Make a list of your parameter of interest (which is a LIST of TWO matrices)
list.of.list.w.matrices.store <- list()

for(i in 1:numboot) {
  list.of.list.w.matrices.store[[i]] <- BStrap_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$trait.regression[[1]]
}

# Template matrix
template.list.of.matrices <- BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$trait.regression[[1]]



# The trade-off can be addressed by studying the conditional regression coefficients:
NA.TrtReg <- lapply( 1:numboot, 
                     function(x) rep(NA, length( unlist(template.list.of.matrices))) )

BTU.TrtReg <- rep(NA, length( unlist(template.list.of.matrices) ) ) # unlist( FinalOUs2$FinalFound$ParamSummary$trait.regression )
BTL.TrtReg <- BTU.TrtReg

for(i in 1:length( unlist(template.list.of.matrices) )){ # unlist(FinalOUs2$FinalFound$ParamSummary$trait.regression)
  BT.TrtReg <- quantile(sapply(relist( unlist(list.of.list.w.matrices.store), NA.TrtReg), # unlist(BT$bootstrapped.parameters$trait.regression)
                               function(x) x[i]), 
                        c(0.025, 0.975))
  
  BTL.TrtReg[i] <- BT.TrtReg[1]
  BTU.TrtReg[i] <- BT.TrtReg[2]
}


BTL.TrtReg <- relist(BTL.TrtReg, template.list.of.matrices) # FinalOUs2$FinalFound$ParamSummary$trait.regression
BTU.TrtReg <- relist(BTU.TrtReg, template.list.of.matrices) # FinalOUs2$FinalFound$ParamSummary$trait.regression


BT.Lower.CI.TrtReg <- BTL.TrtReg
BT.Upper.CI.TrtReg <- BTU.TrtReg


BT.Lower.CI.TrtReg
BT.Upper.CI.TrtReg

# BT.Lower.CI.TrtReg
# [[1]]
# seed.mass  leaf.area  leaf.mass
# plant.height -0.05854712 -0.1240766 0.03578315
# 
# [[2]]
# plant.height  leaf.area  leaf.mass
# seed.mass  -0.06645705 -0.3224163 0.02110724
# 
# [[3]]
# plant.height  seed.mass  leaf.mass
# leaf.area   -0.0896743 -0.2244732 0.09480712
# 
# [[4]]
# plant.height   seed.mass leaf.area
# leaf.mass   0.03134862 0.007127341 0.1061382
# 
# > BT.Upper.CI.TrtReg
# [[1]]
# seed.mass leaf.area leaf.mass
# plant.height 0.1575668 0.2460285 0.4496018
# 
# [[2]]
# plant.height  leaf.area leaf.mass
# seed.mass    0.3602409 0.06168037 0.5117402
# 
# [[3]]
# plant.height  seed.mass leaf.mass
# leaf.area    0.3538901 0.03773292 0.8244828
# 
# [[4]]
# plant.height seed.mass leaf.area
# leaf.mass    0.5360075 0.2852164 0.6735063


#


# BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$trait.regression[[1]] ~~~~~~~~~~~~~~~~~

numboot <- length(BStrap2_OUOU.model6.UT_reanalysis.output)

# Make a list of your parameter of interest (which is a LIST of TWO matrices)
list.of.list.w.matrices.store <- list()

for(i in 1:numboot) {
  list.of.list.w.matrices.store[[i]] <- BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$trait.regression[[1]]
}

# Template matrix
template.list.of.matrices <- BStrap2_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$trait.regression[[1]]



# The trade-off can be addressed by studying the conditional regression coefficients:
NA.TrtReg <- lapply( 1:numboot, 
                     function(x) rep(NA, length( unlist(template.list.of.matrices))) )

BTU.TrtReg <- rep(NA, length( unlist(template.list.of.matrices) ) ) # unlist( FinalOUs2$FinalFound$ParamSummary$trait.regression )
BTL.TrtReg <- BTU.TrtReg

for(i in 1:length( unlist(template.list.of.matrices) )){ # unlist(FinalOUs2$FinalFound$ParamSummary$trait.regression)
  BT.TrtReg <- quantile(sapply(relist( unlist(list.of.list.w.matrices.store), NA.TrtReg), # unlist(BT$bootstrapped.parameters$trait.regression)
                               function(x) x[i]), 
                        c(0.025, 0.975))
  
  BTL.TrtReg[i] <- BT.TrtReg[1]
  BTU.TrtReg[i] <- BT.TrtReg[2]
}


BTL.TrtReg <- relist(BTL.TrtReg, template.list.of.matrices) # FinalOUs2$FinalFound$ParamSummary$trait.regression
BTU.TrtReg <- relist(BTU.TrtReg, template.list.of.matrices) # FinalOUs2$FinalFound$ParamSummary$trait.regression


BT.Lower.CI.TrtReg <- BTL.TrtReg
BT.Upper.CI.TrtReg <- BTU.TrtReg


BT.Lower.CI.TrtReg
BT.Upper.CI.TrtReg


# BT.Lower.CI.TrtReg
# [[1]]
# seed.mass leaf.area  leaf.mass
# plant.height 0.01467066 -0.020572 0.09315393
# 
# [[2]]
# plant.height  leaf.area leaf.mass
# seed.mass   0.07379962 -0.5597859 0.1856745
# 
# [[3]]
# plant.height seed.mass leaf.mass
# leaf.area   -0.0167069 -0.113023 0.7578182
# 
# [[4]]
# plant.height  seed.mass leaf.area
# leaf.mass   0.08827886 0.04028159 0.7543364
# 
# > BT.Upper.CI.TrtReg
# [[1]]
# seed.mass leaf.area leaf.mass
# plant.height 0.08653128 0.1462638  0.291877
# 
# [[2]]
# plant.height  leaf.area leaf.mass
# seed.mass    0.3490927 -0.1501877 0.6193895
# 
# [[3]]
# plant.height   seed.mass leaf.mass
# leaf.area    0.1272246 -0.02873977 0.8537426
# 
# [[4]]
# plant.height seed.mass leaf.area
# leaf.mass    0.2563915 0.1143721 0.8740659












# CREATE -------- Bootstrap.output.summary_v2.R  Bootstrap.output.summary_v3.csv  
# Bootstrap.output.summary_v3.R

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# "Obtain confidence intervals from the boostrap runs"
# "Bootstrap where estimated.model = OUOU.model6.UT_reanalysis but no starting point was set"

# "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ mPsi bootstrap CIs"

# OUOU.model6.UT_reanalysis$FinalFound$ParamsInModel$mPsi
# ##                   1          2         3          4          5           6          7          8          9 ambiguous
# plant.height -1.794485 -1.6772871 -1.226414 -0.8198210 -0.3593010 -0.64421980 -0.2504362 -0.2936231 -0.5459189 -1.224828
# seed.mass    -2.002929 -0.9944204 -0.631878  0.2563999  0.5446443 -0.03456367  0.9046385  0.9084421 -0.5931383 -1.607115
# leaf.area     4.156059  4.6655786  5.848904  6.3214404  6.6656811  7.05776503  7.6804370  8.4272891  7.4212524  4.718261
# leaf.mass     1.408102  1.6812127  2.827140  3.3334513  3.6617489  3.81628988  4.5167630  5.1302196  4.1362553  1.095669

# BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$mPsi[[1]]
# ##                    1         2          3          4          5           6         7          8          9 ambiguous
# plant.height   60.07206   94.0538   39.39154   45.25714   3.897237 -0.63370143 -27.31401  -95.18587   6.893671  103.7702
# seed.mass    -179.51715 -277.7760 -118.25894 -132.39900 -11.362188 -0.02198747  79.45978  276.12123 -23.049238 -304.3749
# leaf.area     125.81938  193.9564   85.88251   97.46944  15.359207  6.82034548 -45.27283 -178.21226  22.324221  213.0087
# leaf.mass      71.86500  110.7785   49.30696   55.75949   8.476058  3.43581971 -26.26487 -103.65953  13.064542  119.5328

# BT.Lower.CI.mPsi
# ##                   1         2          3         4           5          6          7          8           9 ambiguous
# plant.height -10.80073 -11.02280  -8.010128 -3.707952  0.05673275 -0.9096536 -0.1776852 -2.3662296  -5.6815351 -15.05915
# seed.mass    -20.89571 -16.12506 -12.263162 -2.337081 -1.60274621 -0.8831560  1.8265631 -0.0801433 -19.1161977 -37.35587
# leaf.area    -12.29648 -11.15719  -4.255402  1.292269  4.15169097  6.8702421  7.4771881  8.5595074  -0.7116369 -23.15437
# leaf.mass    -12.01464 -12.25033  -5.365844 -1.151545  1.05125819  3.4579691  4.8629546  6.2775954  -4.6347659 -27.59498

# BT.Upper.CI.mPsi
# ##                    1          2         3         4        5          6         7         8         9 ambiguous
# plant.height -1.4230964 -1.8944767 -1.519602 0.8818871 4.243347 -0.1199158  4.043639  5.909911  5.651680  5.113500
# seed.mass    -1.8565784  0.7545646  0.502823 7.1066572 8.152611  0.6341745 11.114576 16.587633  7.311011  8.505829
# leaf.area     4.0790928  4.6251464  5.856558 6.8322282 8.866388  8.0946822 14.313996 23.395347 18.159521 11.473860
# leaf.mass    -0.2332081  0.5656951  2.183543 4.6135853 7.813294  4.5741827 11.009080 18.673412 13.207670  4.052783


# "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ corr.matrix bootstrap CIs"

# OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$corr.matrix
# ##           plant.height  seed.mass  leaf.area leaf.mass
# plant.height    1.0000000 0.18797229 0.40166248 0.4626882
# seed.mass       0.1879723 1.00000000 0.06804039 0.1603691
# leaf.area       0.4016625 0.06804039 1.00000000 0.8459495
# leaf.mass       0.4626882 0.16036910 0.84594945 1.0000000

# BStrap_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$corr.matrix[[1]]
# ##           plant.height   seed.mass   leaf.area leaf.mass
# plant.height   1.00000000  0.09058636  0.24923467 0.1927374
# seed.mass      0.09058636  1.00000000 -0.03220912 0.1529768
# leaf.area      0.24923467 -0.03220912  1.00000000 0.5629821
# leaf.mass      0.19273736  0.15297682  0.56298211 1.0000000

# BT.Lower.CI.corr.matrix
# ##           plant.height   seed.mass   leaf.area  leaf.mass
# plant.height   1.00000000 -0.03851207  0.03419366 0.10691193
# seed.mass     -0.03851207  1.00000000 -0.11166825 0.02468602
# leaf.area      0.03419366 -0.11166825  1.00000000 0.24362366
# leaf.mass      0.10691193  0.02468602  0.24362366 1.00000000

# BT.Upper.CI.corr.matrix
# ##           plant.height seed.mass leaf.area leaf.mass
# plant.height    1.0000000 0.2738692 0.3275419 0.4546645
# seed.mass       0.2738692 1.0000000 0.1616240 0.3526899
# leaf.area       0.3275419 0.1616240 1.0000000 0.7213038
# leaf.mass       0.4546645 0.3526899 0.7213038 1.0000000


# "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ halflives bootstrap CIs"

# OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$phyl.halflife$halflives
# ##                 [,1]        [,2]        [,3]       [,4]
# eigenvalues 67.92723258 51.36840013 27.64034199 22.6840434
# halflife     0.01020426  0.01349365  0.02507737  0.0305566
# %treeheight  1.02042606  1.34936494  2.50773735  3.0556597

# BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives
# ##                          [,1]                 [,2]          [,3]             [,4]
# eigenvalues 10.85025110+2.76155i 10.85025110-2.76155i  2.8738965+0i -2.584564e-02+0i
# halflife     0.06388305+0.00000i  0.06388305+0.00000i  0.2411872+0i -2.681872e+01+0i
# %treeheight  6.38830543+0.00000i  6.38830543+0.00000i 24.1187248+0i -2.681872e+03+0i

# BT.Lower.CI.halflives
# ##                          [,1]                  [,2]                  [,3]          [,4]
# eigenvalues 0.84787593+0.041382i 0.73737370+0.0220511i  0.6300247+0.1136624i  0.4385848+0i
# halflife    0.05613291+0.000000i 0.07732107+0.0000000i  0.1782325+0.0000000i  0.4686547+0i
# %treeheight 5.61329060+0.000000i 7.73210659+0.0000000i 17.8232497+0.0000000i 46.8654730+0i

# BT.Upper.CI.halflives
# ##                         [,1]                 [,2]          [,3]                   [,4]
# eigenvalues 12.5621723+1.31174i  9.2683904-0.655367i   4.365777+0i   0.8938675-0.0592195i
# halflife     0.8175162+0.00000i  0.9402793+0.000000i   1.100197+0i   1.2982591+0.0000000i
# %treeheight 81.7516250+0.00000i 94.0279321+0.000000i 110.019720+0i 129.8259119+0.0000000i


# "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ trait.regression bootstrap CIs"

# OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$trait.regression
# [[1]]         seed.mass  leaf.area leaf.mass
# plant.height 0.06136108 0.03989189 0.2316036
# [[2]]     plant.height  leaf.area leaf.mass
# seed.mass     0.292387 -0.2954212 0.3507967
# [[3]]     plant.height   seed.mass leaf.mass
# leaf.area   0.03820863 -0.05938182 0.8213552
# [[4]]     plant.height  seed.mass leaf.area
# leaf.mass    0.2193269 0.06971672 0.8120834

# BStrap_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$trait.regression[[1]]
# [[1]]         seed.mass leaf.area leaf.mass
# plant.height 0.06862465 0.3418518 0.4232571
# [[2]]     plant.height  leaf.area leaf.mass
# seed.mass     0.775343 -0.8858323 -1.406704
# [[3]]     plant.height  seed.mass  leaf.mass
# leaf.area      1.33628 -0.3064766 -0.4262237
# [[4]]     plant.height  seed.mass  leaf.area
# leaf.mass    0.7969032 -0.2344177 -0.2052955

# BT.Lower.CI.TrtReg
# [[1]]          seed.mass  leaf.area  leaf.mass
# plant.height -0.05854712 -0.1240766 0.03578315
# [[2]]     plant.height  leaf.area  leaf.mass
# seed.mass  -0.06645705 -0.3224163 0.02110724
# [[3]]     plant.height  seed.mass  leaf.mass
# leaf.area   -0.0896743 -0.2244732 0.09480712
# [[4]]     plant.height   seed.mass leaf.area
# leaf.mass   0.03134862 0.007127341 0.1061382

# BT.Upper.CI.TrtReg
# [[1]]        seed.mass leaf.area leaf.mass
# plant.height 0.1575668 0.2460285 0.4496018
# [[2]]     plant.height  leaf.area leaf.mass
# seed.mass    0.3602409 0.06168037 0.5117402
# [[3]]     plant.height  seed.mass leaf.mass
# leaf.area    0.3538901 0.03773292 0.8244828
# [[4]]     plant.height seed.mass leaf.area
# leaf.mass    0.5360075 0.2852164 0.6735063



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# "Obtain confidence intervals from the boostrap runs" 
# "Bootstrap 2 - where estimated.model = OUOU.model6.UT_reanalysis but Start_point_for_optim was set to the lowest AICc OUOU.model6.Di.output model"

# "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ mPsi bootstrap CIs"

# OUOU.model6.UT_reanalysis$FinalFound$ParamsInModel$mPsi
# ##                   1          2         3          4          5           6          7          8          9 ambiguous
# plant.height -1.794485 -1.6772871 -1.226414 -0.8198210 -0.3593010 -0.64421980 -0.2504362 -0.2936231 -0.5459189 -1.224828
# seed.mass    -2.002929 -0.9944204 -0.631878  0.2563999  0.5446443 -0.03456367  0.9046385  0.9084421 -0.5931383 -1.607115
# leaf.area     4.156059  4.6655786  5.848904  6.3214404  6.6656811  7.05776503  7.6804370  8.4272891  7.4212524  4.718261
# leaf.mass     1.408102  1.6812127  2.827140  3.3334513  3.6617489  3.81628988  4.5167630  5.1302196  4.1362553  1.095669

# BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$mPsi[[1]]
# ##                   1         2          3          4          5          6          7          8          9  ambiguous
# plant.height -1.568402 -1.655219 -1.1509489 -0.6237659 -0.2832192 -0.7990058 -0.1505571 -0.2251348  0.1394310 -2.0132771
# seed.mass    -1.419005 -1.133223 -0.4470296  0.2463516  0.5604188 -0.3990421  0.7214417  1.0870931 -0.8708092 -2.0867734
# leaf.area     4.165866  4.620997  6.2355082  6.6084908  6.7894801  7.1880854  7.5847166  8.7502368  7.7682487  4.6125538
# leaf.mass     1.435330  1.692130  3.2301931  3.7205447  3.9258936  3.8551080  4.4705822  5.3055016  4.4436514  0.7697537

# BT.Lower.CI.mPsi
# ##                    1         2         3          4          5          6          7          8         9 ambiguous
# plant.height -2.2704376 -1.895650 -1.400967 -1.0001620 -0.5242265 -0.7660805 -0.4029201 -0.4994766 -1.304082 -2.144338
# seed.mass    -3.1712394 -1.445432 -1.029206 -0.1535334  0.1770848 -0.3053162  0.5090757  0.4482647 -2.244310 -3.299219
# leaf.area     3.1914443  4.279705  5.560611  6.0221187  6.3394689  6.8443546  7.4716812  8.1342098  6.283204  2.729719
# leaf.mass     0.5238222  1.246764  2.527404  3.0119488  3.2988960  3.6007739  4.2796233  4.6652010  2.837349 -1.023412

# BT.Upper.CI.mPsi
# ##                    1          2          3          4          5          6           7          8           9  ambiguous
# plant.height -1.4550522 -1.5099685 -1.0591776 -0.6474169 -0.1561706 -0.5046186 -0.09828723 0.01479124 0.008342299 0.22430171
# seed.mass    -0.6751247 -0.4980257 -0.2442173  0.6651540  0.8749973  0.2361262  1.31191447 1.46230491 0.782302615 0.09528347
# leaf.area     4.8778490  4.9821900  6.1350449  6.5908740  6.9232127  7.3129414  7.98564243 8.88581353 8.440263474 6.55260217
# leaf.mass     2.2478428  1.9863321  3.1416976  3.6275217  3.9855083  4.1212997  4.81160606 5.63923494 5.192711603 2.47161173


# "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ corr.matrix bootstrap CIs"

# OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$corr.matrix
# ##           plant.height  seed.mass  leaf.area leaf.mass
# plant.height    1.0000000 0.18797229 0.40166248 0.4626882
# seed.mass       0.1879723 1.00000000 0.06804039 0.1603691
# leaf.area       0.4016625 0.06804039 1.00000000 0.8459495
# leaf.mass       0.4626882 0.16036910 0.84594945 1.0000000

# BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$corr.matrix[[1]]
# ##           plant.height  seed.mass  leaf.area leaf.mass
# plant.height    1.0000000 0.16077950 0.36094296 0.4079993
# seed.mass       0.1607795 1.00000000 0.06683799 0.1413114
# leaf.area       0.3609430 0.06683799 1.00000000 0.8281161
# leaf.mass       0.4079993 0.14131140 0.82811615 1.0000000

# BT.Lower.CI.corr.matrix
# ##           plant.height   seed.mass   leaf.area  leaf.mass
# plant.height   1.00000000  0.07833365  0.29192305 0.32665566
# seed.mass      0.07833365  1.00000000 -0.03871368 0.07210203
# leaf.area      0.29192305 -0.03871368  1.00000000 0.79164788
# leaf.mass      0.32665566  0.07210203  0.79164788 1.00000000

# BT.Upper.CI.corr.matrix
# ##           plant.height  seed.mass  leaf.area leaf.mass
# plant.height    1.0000000 0.20633928 0.41563710 0.4584034
# seed.mass       0.2063393 1.00000000 0.09792459 0.1982963
# leaf.area       0.4156371 0.09792459 1.00000000 0.8602964
# leaf.mass       0.4584034 0.19829634 0.86029644 1.0000000


# "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ halflives bootstrap CIs"

# OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$phyl.halflife$halflives
# ##                 [,1]        [,2]        [,3]       [,4]
# eigenvalues 67.92723258 51.36840013 27.64034199 22.6840434
# halflife     0.01020426  0.01349365  0.02507737  0.0305566
# %treeheight  1.02042606  1.34936494  2.50773735  3.0556597

# BStrap2_OUOU.model6.UT_reanalysis.output[[1]]$bootstrapped.parameters$phyl.halflife[[1]]$halflives
# ##                    [,1]           [,2]                 [,3]                 [,4]
# eigenvalues 48.21347832+0i 42.29565065+0i 21.85387472+1.24552i 21.85387472-1.24552i
# halflife     0.01437663+0i  0.01638814+0i  0.03171736+0.00000i  0.03171736+0.00000i
# %treeheight  1.43766267+0i  1.63881432+0i  3.17173586+0.00000i  3.17173586+0.00000i

# BT.Lower.CI.halflives
# ##                          [,1]           [,2]                 [,3]           [,4]
# eigenvalues 45.98779664+2.22117i 39.97204693+0i 20.56118790+2.57106i 17.66493095+0i
# halflife     0.01143646+0.00000i  0.01351405+0i  0.02353371+0.00000i  0.02753179+0i
# %treeheight  1.14364599+0.00000i  1.35140527+0i  2.35337130+0.00000i  2.75317895+0i

# BT.Upper.CI.halflives
# ##                    [,1]                 [,2]           [,3]                [,4]
# eigenvalues 60.60901200+0i 51.29136878-3.26242i 29.45576954+0i 25.17659668-0.8757i
# halflife     0.01507248+0i  0.01734082+0.00000i  0.03371149+0i  0.03923977+0.0000i
# %treeheight  1.50724820+0i  1.73408170+0.00000i  3.37114927+0i  3.92397698+0.0000i


# "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ trait.regression bootstrap CIs"

# OUOU.model6.UT_reanalysis$FinalFound$ParamSummary$trait.regression
# [[1]]         seed.mass  leaf.area leaf.mass
# plant.height 0.06136108 0.03989189 0.2316036
# [[2]]     plant.height  leaf.area leaf.mass
# seed.mass     0.292387 -0.2954212 0.3507967
# [[3]]     plant.height   seed.mass leaf.mass
# leaf.area   0.03820863 -0.05938182 0.8213552
# [[4]]     plant.height  seed.mass leaf.area
# leaf.mass    0.2193269 0.06971672 0.8120834

# BStrap2_OUOU.model6.UT_reanalysis.output[[i]]$bootstrapped.parameters$trait.regression[[1]]
# [[1]]         seed.mass leaf.area leaf.mass
# plant.height 0.03922679 0.1099797 0.1239238
# [[2]]     plant.height  leaf.area leaf.mass
# seed.mass     0.194469 -0.4427459 0.4237023
# [[3]]     plant.height   seed.mass leaf.mass
# leaf.area    0.1014722 -0.08239891 0.8267649
# [[4]]     plant.height  seed.mass leaf.area
# leaf.mass    0.1104171 0.07615085 0.7984156

# BT.Lower.CI.TrtReg
# [[1]]         seed.mass leaf.area  leaf.mass
# plant.height 0.01467066 -0.020572 0.09315393
# [[2]]     plant.height  leaf.area leaf.mass
# seed.mass   0.07379962 -0.5597859 0.1856745
# [[3]]     plant.height seed.mass leaf.mass
# leaf.area   -0.0167069 -0.113023 0.7578182
# [[4]]     plant.height  seed.mass leaf.area
# leaf.mass   0.08827886 0.04028159 0.7543364

# BT.Upper.CI.TrtReg
# [[1]]         seed.mass leaf.area leaf.mass
# plant.height 0.08653128 0.1462638  0.291877
# [[2]]      plant.height  leaf.area leaf.mass
# seed.mass    0.3490927 -0.1501877 0.6193895
# [[3]]     plant.height   seed.mass leaf.mass
# leaf.area    0.1272246 -0.02873977 0.8537426
# [[4]]     plant.height seed.mass leaf.area
# leaf.mass    0.2563915 0.1143721 0.8740659


